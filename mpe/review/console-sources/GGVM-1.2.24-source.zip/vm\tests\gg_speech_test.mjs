// Run actual GGVM packets/receiver/player. CIA flags are modeled here;
// instruction-cycle/audio quality validation is a separate VICE/hardware gate.
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {C64TerminalCpu} from './helpers/c64-terminal-cpu.mjs';
import {crc16Ccitt} from './helpers/crc16.mjs';import {loadGgTerminal} from '../gg/speech-client.mjs';
const out=path.resolve(process.argv[2]);const manifest=JSON.parse(fs.readFileSync(path.join(out,'client.json')));
const {buildMpe3TitleTerminal,MPE3_TITLE_TERMINAL_STATE:state}=await loadGgTerminal(path.resolve(import.meta.dirname,'../client'));
const program=buildMpe3TitleTerminal({gameplay:true,enable1351Mouse:false,packetReplay:true,diagnosticTitle:manifest.diagnosticTitle,diagnosticFooter:manifest.diagnosticFooter});
assert.deepEqual(Buffer.from(program.prg),fs.readFileSync(path.join(out,'ggvm.prg')));
const clip=fs.readFileSync(path.join(out,'boot-speech.pcm4'));assert.ok(clip.length>5000&&clip.length<7000);
function packet(type,seq,flags,payload){const b=Buffer.alloc(payload.length+10);b.set([77,51,1,type,seq,flags,payload.length,0]);b.set(payload,8);b.writeUInt16LE(crc16Ccitt(b.subarray(0,-2)),b.length-2);return b;}
const cell=Buffer.from([0,0,0,0,0,0,0,0,0,0,0x10,1]);const sid=Buffer.alloc(26);sid[1]=0x34;sid[2]=0x12;sid[5]=0x41;sid[7]=0xf0;sid[25]=15;
function run(data,{fault=false,badBegin=false,badOffset=false,earlyPlay=false,pal=false}={}){
  const packets=[];const add=(t,f,p)=>packets.push(packet(t,packets.length+1,f,Buffer.from(p)));
  add(1,0x0b,cell);add(2,0x21,sid);add(6,0,[1,0,badBegin?1:data.length&255,badBegin?32:data.length>>8]);
  if(!earlyPlay)for(let offset=0;offset<data.length;offset+=226)add(6,1,[(offset+(badOffset?1:0))&255,offset>>8,...data.subarray(offset,offset+226)]);
  add(6,2,[data.length&255,data.length>>8]);add(2,0x21,sid);
  let index=0,started=false,replays=0,playing=false;const acks=[],samples=[];
  const publish=c=>{c.ram.set(packets[index],0xdf00);c.ram[0xdff7]=packets[index][4];c.ram[0xdff5]=2;};
  const service={onWrite(c,a,v){
    if(a===0xdff4&&v===1&&!started){started=true;publish(c);}
    if(a===0xdff4&&v===6){replays++;c.ram.set(packets[index],program.stageAddress);c.ram[0x02f0]=0xa5;c.ram[0xdff5]=0x12;}
    if(a===0xd418&&c.pc>=program.labels.gg_speech_sample&&c.pc<program.labels.gg_speech_wait){playing=true;samples.push(v);assert.equal(c.ram[0xdc04],pal?122:127);}
    if(a===0xdff6&&started){assert.equal(v,packets[index][4]);if(packets[index][3]===6&&packets[index][5]===2)assert.equal(samples.length,data.length*2);
      acks.push(v);if(index===2){c.ram[0x7fff]=0xa5;c.ram[0xa000]=0xa5;}if(++index<packets.length)publish(c);}
  }};
  const cpu=new C64TerminalCpu(program,service,{rasterInterruptPeriod:2000,recordWrites:false});cpu.ram[0x02a6]=pal?1:0;
  const read=cpu.read.bind(cpu);cpu.read=a=>{const v=read(a);if(a===0xdc0d&&(cpu.ram[0xdc0e]&1))return 1;if(fault&&index===3&&a===0xdf0c)return v^8;return v;};
  cpu.runUntil(c=>acks.length===packets.length||c.pc===program.labels.terminal_error_hold,12_000_000);
  if(badBegin||badOffset||earlyPlay){assert.equal(cpu.ram[state.error],8);assert.equal(playing,false);assert.ok(acks.length<packets.length);return;}
  assert.equal(acks.length,packets.length);assert.equal(cpu.ram[state.error],0);assert.equal(replays,fault?1:0);
  assert.deepEqual(samples,[...data].flatMap(b=>[b>>4,b&15]));assert.equal(cpu.ram[0x7fff],0xa5);assert.equal(cpu.ram[0xa000],0xa5);
  assert.equal(cpu.ram[0xdc0e],0);assert.equal(cpu.ram[0xd418],15);assert.equal(cpu.ram[0xd404],0x41);assert.equal(cpu.ram[0xd400],0x34);
}
run(clip);run(clip,{pal:true});run(clip,{fault:true});run(clip,{badBegin:true});run(clip,{badOffset:true});run(clip,{earlyPlay:true});
run(Buffer.alloc(8192,0xa3));run(Buffer.from([0x5a]));
// Local, ROM-derived listening aid only; never include it in the runtime ZIP.
const pcm=Buffer.from([...clip].flatMap(b=>[(b>>4)*17,(b&15)*17]));const wav=Buffer.alloc(44+pcm.length);
wav.write('RIFF');wav.writeUInt32LE(wav.length-8,4);wav.write('WAVEfmt ',8);wav.writeUInt32LE(16,16);wav.writeUInt16LE(1,20);wav.writeUInt16LE(1,22);wav.writeUInt32LE(8000,24);wav.writeUInt32LE(8000,28);wav.writeUInt16LE(1,32);wav.writeUInt16LE(8,34);wav.write('data',36);wav.writeUInt32LE(pcm.length,40);pcm.copy(wav,44);fs.writeFileSync(path.join(out,'boot-speech-source.wav'),wav);
console.log(`PASS GG speech receiver: ${pcm.length} exact SID samples, PAL/NTSC clocks, CRC replay without duplicate playback, size/offset/truncation rejection, 1/8192-byte bounds and music restoration`);
