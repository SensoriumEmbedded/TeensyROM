// GGVM-only, CRC-validated packet 6: begin, contiguous packed data, play.
// F1 leaves $8000-$9fff free. The final packet stays unacknowledged while
// the CIA-timed player runs, and GGVM holds all video/guest work until ACK.
import {loadNesTerminal} from '../../nes/tools/nes_terminal.mjs';
export const SPEECH={type:6,buffer:0x8000,capacity:8192,rate:8000};
export function emitSpeechClient(e,state,stage){
  const get=a=>e.abs(0xad,a,'read'),put=a=>e.abs(0x8d,a,'write');
  const set=(a,v)=>{e.emit(0xa9,v);put(a);},jump=l=>e.abs(0x4c,l);
  const requireEq=(a,v)=>{get(a);e.emit(0xc9,v);e.jumpUnless(0xf0,'error_sid');};
  e.label('gg_speech_packet');get(stage+5);e.branch(0xf0,'gg_speech_begin');
  e.emit(0xc9,1);e.jumpUnless(0xd0,'gg_speech_data');e.emit(0xc9,2);e.jumpUnless(0xd0,'gg_speech_play_packet');jump('error_sid');
  e.label('gg_speech_begin');requireEq(stage+6,4);requireEq(stage+8,1);requireEq(stage+9,0);
  get(stage+10);e.abs(0x0d,stage+11,'read');e.jumpUnless(0xd0,'error_sid');
  get(stage+11);e.emit(0xc9,0x20);e.branch(0x90,'gg_speech_capacity_ok');e.branch(0xd0,'gg_speech_bad_size');
  get(stage+10);e.branch(0xf0,'gg_speech_capacity_ok');e.label('gg_speech_bad_size');jump('error_sid');
  e.label('gg_speech_capacity_ok');get(stage+10);put('gg_speech_total');get(stage+11);put('gg_speech_total_hi');
  set('gg_speech_received',0);set('gg_speech_received_hi',0);set('gg_speech_active',1);jump('ack_packet');
  e.label('gg_speech_data');requireEq('gg_speech_active',1);get(stage+6);e.emit(0xc9,3);e.jumpUnless(0xb0,'error_sid');
  for(const [offset,name] of [[8,'gg_speech_received'],[9,'gg_speech_received_hi']]){get(stage+offset);e.abs(0xcd,name,'read');e.jumpUnless(0xf0,'error_sid');}
  get(stage+6);e.emit(0x38,0xe9,2);put('gg_speech_chunk');e.emit(0x18);e.abs(0x6d,'gg_speech_received','read');put('gg_speech_next');
  get('gg_speech_received_hi');e.emit(0x69,0);put('gg_speech_next_hi');e.abs(0xcd,'gg_speech_total_hi','read');e.branch(0x90,'gg_speech_copy');e.jumpUnless(0xf0,'error_sid');
  get('gg_speech_next');e.abs(0xcd,'gg_speech_total','read');e.branch(0x90,'gg_speech_copy');e.jumpUnless(0xf0,'error_sid');
  e.label('gg_speech_copy');get('gg_speech_received');e.emit(0x85,0xf0);get('gg_speech_received_hi');e.emit(0x18,0x69,0x80,0x85,0xf1,0xa0,0);
  e.label('gg_speech_copy_byte');e.abs(0xb9,stage+10,'read');e.emit(0x91,0xf0,0xc8);e.abs(0xcc,'gg_speech_chunk','read');e.branch(0xd0,'gg_speech_copy_byte');
  get('gg_speech_next');put('gg_speech_received');get('gg_speech_next_hi');put('gg_speech_received_hi');jump('ack_packet');
  e.label('gg_speech_play_packet');requireEq(stage+6,2);requireEq('gg_speech_active',1);
  for(const [offset,total,received] of [[8,'gg_speech_total','gg_speech_received'],[9,'gg_speech_total_hi','gg_speech_received_hi']]){
    get(stage+offset);e.abs(0xcd,total,'read');e.jumpUnless(0xf0,'error_sid');e.abs(0xcd,received,'read');e.jumpUnless(0xf0,'error_sid');
  }
  set('gg_speech_active',0);e.abs(0x20,'gg_speech_play');jump('ack_packet');
  e.label('gg_speech_play');e.emit(0x08,0x78); // PHP, SEI: raster work cannot disturb sample timing.
  e.abs(0x20,'clear_sid');set(0xdc0e,0);set(0xdc0d,0x7f);get(0xdc0d);
  set(0xdc05,0);get(state.videoTiming);e.branch(0xf0,'gg_speech_ntsc');set(0xdc04,122);jump('gg_speech_clock_ready');
  e.label('gg_speech_ntsc');set(0xdc04,127);e.label('gg_speech_clock_ready');
  // Pulse + TEST creates a DC source for the 8580 volume DAC; also works on
  // 6581. All three voices boost the clip, then clear_sid restores silence.
  for(const offset of [0,7,14]){set(0xd406+offset,0xf0);set(0xd404+offset,0x49);}
  set(0xdc0e,0x11);e.emit(0xa2,32); // Let the 2 ms attack settle at zero master volume.
  e.label('gg_speech_prime');e.abs(0x20,'gg_speech_wait');e.emit(0xca);e.branch(0xd0,'gg_speech_prime');
  get('gg_speech_total_hi');e.emit(0x18,0x69,0x80);put('gg_speech_end_hi');set('gg_speech_source_hi',0x80);e.emit(0xa0,0);
  e.label('gg_speech_byte');e.emit(0xb9,0);e.label('gg_speech_source_hi');e.emit(0x80);put('gg_speech_byte_value');e.emit(0x4a,0x4a,0x4a,0x4a);
  e.abs(0x20,'gg_speech_sample');get('gg_speech_byte_value');e.emit(0x29,15);e.abs(0x20,'gg_speech_sample');
  e.emit(0xc8);e.branch(0xd0,'gg_speech_pointer_ready');e.abs(0xee,'gg_speech_source_hi','write');e.label('gg_speech_pointer_ready');
  e.emit(0x98);e.abs(0xcd,'gg_speech_total','read');e.branch(0xd0,'gg_speech_byte');
  get('gg_speech_source_hi');e.abs(0xcd,'gg_speech_end_hi','read');e.branch(0xd0,'gg_speech_byte');
  // Hold the last sample for its complete interval before silencing.
  e.abs(0x20,'gg_speech_wait');set(0xdc0e,0);get(0xdc0d);e.abs(0x20,'clear_sid');set(0xd019,1);e.emit(0x28,0x60);
  e.label('gg_speech_sample');put('gg_speech_level');e.abs(0x20,'gg_speech_wait');get('gg_speech_level');put(0xd418);e.emit(0x60);
  e.label('gg_speech_wait');get(0xdc0d);e.emit(0x29,1);e.branch(0xf0,'gg_speech_wait');e.emit(0x60);
  for(const label of ['total','total_hi','received','received_hi','next','next_hi','chunk','active','byte_value','level','end_hi']){e.label('gg_speech_'+label);e.emit(0);}
}
export function loadGgTerminal(root){return loadNesTerminal(root,{transformSource(source){
  const replace=(before,after)=>{if(!source.includes(before)||source.indexOf(before)!==source.lastIndexOf(before))throw Error('Review GG speech overlay: shared terminal changed');source=source.replace(before,after);};
  replace('  e.emit(0xc9,5);e.jumpUnless(0xd0,"mpe_video_packet");','  e.emit(0xc9,6);e.jumpUnless(0xd0,"gg_speech_packet");\n  e.emit(0xc9,5);e.jumpUnless(0xd0,"mpe_video_packet");');
  replace("emitVideoClient(e,state,stage,'nes_capture_input','nes_crop_active');","emitVideoClient(e,state,stage,'nes_capture_input','nes_crop_active'); emitSpeechClient(e,state,stage);");
  return `import {emitSpeechClient} from '${import.meta.url}';\n`+source;
}});}
