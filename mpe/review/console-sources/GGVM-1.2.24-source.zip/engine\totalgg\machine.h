// SPDX-License-Identifier: MIT
#pragma once
#include <stdint.h>
#include <stddef.h>
namespace gg {
constexpr unsigned ClockHz=3579545,MaxRomBytes=1048576,SaveBytes=32768;
struct Video {void *context;void (*line)(void*,unsigned,const uint8_t*);void (*frame)(void*);};
struct RomReader {void *context;const uint8_t *(*page)(void*,size_t);};
bool start(const uint8_t *firstBank,size_t size,uint32_t crc,Video video,RomReader reader,int console=0);
void stop();void run(unsigned cycles);void buttons(uint8_t held);void capture(bool enabled);
void sid(uint8_t out[26],uint32_t sidClock=1022727);
bool pinned(const uint8_t *bank,size_t bytes);
const char *error();uint64_t ticks();unsigned frames();
uint8_t peek(uint16_t);void poke(uint16_t,uint8_t);
uint8_t readPort(uint8_t);void writePort(uint8_t,uint8_t);
uint8_t *saveData();unsigned saveBytes();uint32_t saveRevision();
unsigned stateBytes();
unsigned speechBytes();const uint8_t *speechData();void speechConsumed();
}
