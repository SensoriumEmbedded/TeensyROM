import fs from 'node:fs';import path from 'node:path';import zlib from 'node:zlib';
import {coreObjects,command,root} from './build-gg-core.mjs';
const rom=process.argv[2],out=path.resolve(process.argv[3]??'build/gg-test');if(!rom)throw Error('Pass a local .gg ROM path');
const {prefix,objects,base}=coreObjects(out);const exe=path.join(out,'gg_module_test.exe');
command(prefix+'g++.exe',['-std=c++17','-O2','-static','-DSMS_PIXEL_WIDTH=8','-I'+base,'-I'+path.join(base,'scheduler'),'-ffunction-sections','-fdata-sections','-Wl,--gc-sections',path.join(root,'vm/tests/gg_module_test.cpp'),path.join(base,'machine.cpp'),...objects,'-o',exe]);
const result=command(exe,[path.resolve(rom),out]);console.log(result);fs.writeFileSync(path.join(out,'verification.txt'),result);
const crc=b=>{let c=0xffffffff;for(const v of b){c^=v;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;};
function chunk(type,data){const body=Buffer.concat([Buffer.from(type),data]),head=Buffer.alloc(4),tail=Buffer.alloc(4);head.writeUInt32BE(data.length);tail.writeUInt32BE(crc(body));return Buffer.concat([head,body,tail]);}
function png(name,indexed,w,h,palette){const raw=Buffer.alloc(h*(w*3+1));for(let y=0;y<h;y++)for(let x=0;x<w;x++){const p=y*(w*3+1)+1+x*3;raw.set(palette(indexed[y*w+x]),p);}const ih=Buffer.alloc(13);ih.writeUInt32BE(w);ih.writeUInt32BE(h,4);ih[8]=8;ih[9]=2;fs.writeFileSync(path.join(out,name),Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ih),chunk('IDAT',zlib.deflateSync(raw)),chunk('IEND',Buffer.alloc(0))]));}
const vic=[[0,0,0],[255,255,255],[136,57,50],[103,182,189],[139,63,150],[85,160,73],[64,49,141],[191,206,114],[139,84,41],[87,66,0],[184,105,98],[80,80,80],[120,120,120],[148,224,137],[120,105,196],[159,159,159]];
for(const name of ['title','level','play']){png(name+'.png',fs.readFileSync(path.join(out,name+'.rgb332')),160,144,i=>[Math.round((i>>5)*255/7),Math.round(((i>>2)&7)*255/7),(i&3)*85]);png(name+'-c64.png',fs.readFileSync(path.join(out,name+'.rgb332.vic')),320,200,i=>vic[i]);}
console.log(command(process.execPath,[path.join(root,'vm/gg/build-client.mjs'),'--output-prg',path.join(out,'ggvm.prg'),'--output-boot-bank',path.join(out,'boot.bin'),'--manifest',path.join(out,'client.json')]).trim());
const clientResult=command(process.execPath,[path.join(root,'vm/tests/gg_client_test.mjs'),out]);console.log(clientResult);fs.appendFileSync(path.join(out,'verification.txt'),clientResult);
const speechResult=command(process.execPath,[path.join(root,'vm/tests/gg_speech_test.mjs'),out]);console.log(speechResult);fs.appendFileSync(path.join(out,'verification.txt'),speechResult);
