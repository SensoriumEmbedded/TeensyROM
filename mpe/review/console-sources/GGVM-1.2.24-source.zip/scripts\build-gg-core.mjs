// Independent Game Gear module build; no firmware changes or ROM bundling.
import fs from 'node:fs';import path from 'node:path';import {spawnSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
export const root=path.resolve(import.meta.dirname,'..');
export const cSources=['core/sms.c','core/sms_bus.c','core/sms_z80.c','core/sms_joypad.c','core/sms_vdp.c','core/sms_rom_database.c','scheduler/scheduler.c','psg.c'];
export function command(exe,args){const r=spawnSync(exe,args,{cwd:root,env:{...process.env,PATH:'C:/msys64/mingw64/bin;'+process.env.PATH},encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});if(r.error||r.status)throw Error(exe+' exit '+r.status+' '+(r.error??'')+'\n'+r.stdout+r.stderr);return r.stdout;}
export function coreObjects(out,arm=false){fs.mkdirSync(out,{recursive:true});const prefix=arm?(process.env.MPE_ARM_PREFIX??path.join(root,'build/toolchain/Arduino15/packages/teensy/tools/teensy-compile/11.3.1/arm/bin/arm-none-eabi-')):'C:/msys64/mingw64/bin/';
 const base=path.join(root,'engine/totalgg');const flags=['-std=c99','-Os','-DNDEBUG','-DSMS_DEBUG=0','-DSMS_ENABLE_FORCE_INLINE=0','-DSMS_PIXEL_WIDTH=8','-ffunction-sections','-fdata-sections','-fstack-usage','-I'+base,'-I'+path.join(base,'scheduler')];
 if(arm)flags.push('-mcpu=cortex-m7','-mthumb','-mfpu=fpv5-d16','-mfloat-abi=hard','-fno-unwind-tables');
 const objects=cSources.map((rel,i)=>{const obj=path.join(out,'gg'+i+'.o');command(prefix+'gcc.exe',[...flags,'-c',path.join(base,rel),'-o',obj]);return obj;});return {prefix,objects,base};}
export function build(out){out=path.resolve(out);const {prefix,objects,base}=coreObjects(out,true);const elf=path.join(out,'ggvm.elf');
 command(prefix+'g++.exe',['-mcpu=cortex-m7','-mthumb','-mfpu=fpv5-d16','-mfloat-abi=hard','-std=c++17','-Os','-DNDEBUG','-DSMS_PIXEL_WIDTH=8','-fno-exceptions','-fno-rtti','-fno-threadsafe-statics','-ffunction-sections','-fdata-sections','-fno-unwind-tables','-fno-asynchronous-unwind-tables','-fstack-usage','-nostartfiles','-I'+base,'-I'+path.join(base,'scheduler'),'-T',path.join(root,'vm/abi/module.ld'),'-Wl,--gc-sections','-Wl,-Map='+path.join(out,'ggvm.map'),path.join(root,'vm/gg/ggvm.cpp'),path.join(base,'machine.cpp'),...objects,'-Wl,--start-group','-lc','-lm','-lgcc','-Wl,--end-group','-o',elf]);
 if(command(prefix+'nm.exe',['-u',elf]).trim())throw Error('Unresolved module imports');const nm=command(prefix+'nm.exe',['-n',elf]);if(/_GLOBAL__sub_I|\b(malloc|calloc|realloc|free)\b/.test(nm))throw Error('Heap or dynamic initialization present');
 const sizes=command(prefix+'size.exe',['-A',elf]);const bss=Number(sizes.match(/^\.bss\s+(\d+)/m)?.[1]??0);
 for(const s of ['text','data'])command(prefix+'objcopy.exe',['-O','binary','--only-section=.'+s,elf,path.join(out,s+'.bin')]);
 const code=fs.readFileSync(path.join(out,'text.bin')),data=fs.readFileSync(path.join(out,'data.bin'));if(code.length>98304||data.length+bss>188416)throw Error('GGVM memory limits exceeded: '+sizes);
 const crc=b=>{let c=0xffffffff;for(const v of b){c^=v;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;};
 const entry=parseInt(nm.match(/^([0-9a-f]+) T vm_entry$/m)?.[1]??'',16)|1;const header=Buffer.alloc(64);const payload=Buffer.concat([code,data]);
 [0x314d564d,2,64,code.length,data.length,bss,entry,0x18000,0x20014000,127,crc(payload),0].forEach((v,i)=>header.writeUInt32LE(v>>>0,4*i));header.writeUInt32LE(crc(header),44);fs.writeFileSync(path.join(out,'engine.mvm'),Buffer.concat([header,payload]));
 const result={code:code.length,data:data.length,bss,workspace:196608-data.length-bss,guestCache:524288,abi:2,requiredServices:127,profile:0};fs.writeFileSync(path.join(out,'memory.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));return result;
}
if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url)build(process.argv[2]??'build/gg-core');
