// SPDX-License-Identifier: MIT
// Exercise the real module, mapper/cache, video ownership, input and battery store.
#include <cassert>
#include <vector>
#include <map>
#include <string>
#include <fstream>
#include <iterator>
#include <cstdio>
#include <filesystem>
#include "../gg/ggvm.cpp"
#include "../video/mpe_video_live.cpp"
static std::map<std::string,std::vector<uint8_t>> files;
static std::map<unsigned,std::string> handles;
static std::vector<VmFileInfo> directoryEntries;
static uint8_t guest[524288+32],workspace[16384];
static uint8_t receivedMenu[1000][10];static unsigned replacedCells;
static std::vector<uint8_t> speechFixture;static unsigned speechTotal,speechPlays;
static unsigned nextHandle=1,dirCursor,now,reads,writes,pictures,packets,videoCalls;
static bool waiting,failWrite,failFlush,failRead,saveDirectory;
static uint32_t frozen,gen;static std::string output;
static uint32_t clockNow(){return now;}
static uint32_t openFile(const char*p,VmFileInfo*i){*i={};std::string path=p;
    if(path=="/VMS/GGVM/ROMS"||(path=="/VMS/GGVM/SAVES"&&saveDirectory)){i->directory=1;dirCursor=0;}
    else {auto it=files.find(path);if(it==files.end())return 0;i->bytes=it->second.size();}
    handles[nextHandle]=path;return nextHandle++;
}
static int32_t readFile(uint32_t h,uint32_t offset,void*p,uint32_t n){reads++;if(failRead)return -1;auto it=handles.find(h);assert(it!=handles.end());auto f=files.find(it->second);assert(f!=files.end());if(offset>f->second.size()||n>f->second.size()-offset)return -1;memcpy(p,f->second.data()+offset,n);return n;}
static void closeFile(uint32_t h){assert(handles.erase(h)==1);}
static int32_t nextFile(uint32_t h,VmFileInfo*i){assert(handles[h]=="/VMS/GGVM/ROMS");if(dirCursor==directoryEntries.size())return 0;*i=directoryEntries[dirCursor++];return 1;}
static uint32_t openFlags(const char*p,uint32_t flags,VmFileInfo*i){assert(flags==(VM_OPEN_WRITE|VM_OPEN_CREATE|VM_OPEN_TRUNCATE));if(failWrite)return 0;files[p]={};return openFile(p,i);}
static int32_t writeFile(uint32_t h,uint32_t pos,const void*p,uint32_t n){writes++;if(failWrite)return -1;auto &f=files[handles[h]];assert(pos<=f.size());if(pos+n>f.size())f.resize(pos+n);memcpy(f.data()+pos,p,n);return n;}
static int32_t fileOp(VmFsRequest*r){if(r->operation==VmFsOp::Mkdir){saveDirectory=true;return 0;}if(r->operation==VmFsOp::Flush)return failFlush?-1:0;if(r->operation==VmFsOp::Close){closeFile(r->handle);return 0;}assert(false);return -1;}
static bool yield(){return false;}static void fail(uint8_t c,uint32_t d){fprintf(stderr,"FAIL MODULE %u %u\n",c,d);assert(false);}
static bool configure(const VmIndexedVideoSetup*s){assert(s->default_mode==0&&s->capabilities==1&&s->reserved==3&&s->workspace_bytes==24576);return true;}
static VmVideoResult video(VmIndexedFrame*f){assert(f->width==160&&f->height==144&&f->stride==160&&f->colors==256);uint32_t hash=vm_crc32(f->pixels,f->pixel_bytes)^vm_crc32(f->palette,f->palette_bytes);
    if(!waiting){waiting=true;videoCalls=0;frozen=hash;gen=f->generation;}assert(gen==f->generation&&hash==frozen);
    if(++videoCalls<12)return VmVideoResult::Busy;waiting=false;pictures++;f->resolved_mode=0;return VmVideoResult::Transferred;}
static void turns(const VmModule*m,unsigned n){for(unsigned i=0;i<n;i++){now+=100;m->pump();VmPacket p{};if(m->packet(&p)){assert(p.length<=228);packets++;
    if(p.type==6){
        if(p.flags==0){assert(p.length==4&&p.payload[0]==1&&!p.payload[1]);speechTotal=p.payload[2]|unsigned(p.payload[3])<<8;assert(speechTotal&&speechTotal<=8192);speechFixture.clear();}
        else if(p.flags==1){assert(p.length>2&&(p.payload[0]|unsigned(p.payload[1])<<8)==speechFixture.size());speechFixture.insert(speechFixture.end(),p.payload+2,p.payload+p.length);assert(speechFixture.size()<=speechTotal);}
        else {assert(p.flags==2&&p.length==2&&speechFixture.size()==speechTotal&&(p.payload[0]|unsigned(p.payload[1])<<8)==speechTotal);speechPlays++;
            assert(speechTotal>5000&&speechTotal<7000);std::ofstream sample(output+"/boot-speech.pcm4",std::ios::binary);sample.write((const char*)speechFixture.data(),speechFixture.size());assert(sample);
            const auto tick=gg::ticks();const auto hash=vm_crc32(ggvm::display.pixels,sizeof ggvm::display.pixels);const auto frames=pictures;
            for(unsigned pause=0;pause<100;pause++){now+=speechTotal*250/100;m->pump();VmPacket held{};assert(!m->packet(&held));assert(gg::ticks()==tick&&pictures==frames&&hash==vm_crc32(ggvm::display.pixels,sizeof ggvm::display.pixels));}
        }
    }
    if(p.type==1){assert(p.length%12==0);for(unsigned j=0;j<p.length;j+=12){auto c=p.payload[j]|unsigned(p.payload[j+1])<<8;assert(c<1000);memcpy(receivedMenu[c],p.payload+j+2,10);if(p.flags&1)replacedCells++;}}
    m->ack();}}}
static void button(const VmModule*m,uint8_t b,unsigned n=300){VmInput in{b,0,0,0x83};m->input(&in);turns(m,n);}
static VmHost makeHost(){VmHost h{};h.abi=2;h.bytes=offsetof(VmHost,video_indexed)+sizeof(h.video_indexed);h.services=127;h.package_root="/VMS/GGVM";h.content_path="";h.workspace=workspace;h.workspace_bytes=8192;h.guest_ram=guest;h.guest_ram_bytes=524288;h.micros_now=clockNow;h.open=openFile;h.read=readFile;h.next=nextFile;h.close=closeFile;h.open_flags=openFlags;h.write=writeFile;h.file_op=fileOp;h.should_yield=yield;h.fail=fail;h.video_configure=configure;h.video_indexed=video;return h;}
static void snapshot(const char*name){std::ofstream f(output+"/"+name,std::ios::binary);f.write((const char*)ggvm::display.pixels,sizeof ggvm::display.pixels);assert(f);
    mpe_video::LiveConverter converter;mpe_video::LiveFrame frame{};mpe_video::IndexedSource src{ggvm::display.pixels,ggvm::palette,160,144,160,256,3};assert(converter.render(src,0,frame));
    std::ofstream v(output+"/"+name+".vic",std::ios::binary);for(unsigned y=0;y<200;y++)for(unsigned x=0;x<320;x++){auto c=frame.cells[(y/8)*40+x/8];uint8_t colors[4]={frame.background,uint8_t(c[8]>>4),uint8_t(c[8]&15),c[9]};uint8_t p=colors[(c[y&7]>>(6-2*((x/2)&3)))&3];if(y<28||y>=172)assert(p==0);v.put(p);}assert(v);
}
static void addDirectoryEntry(const std::string &name,unsigned bytes,bool directory=false){VmFileInfo info{};assert(name.size()<sizeof info.name);strcpy(info.name,name.c_str());info.bytes=bytes;info.directory=directory;directoryEntries.push_back(info);}
static void pickerTests(VmHost &h){
    const auto original=directoryEntries;directoryEntries.clear();const auto &sonic=files.at("/VMS/GGVM/ROMS/Sonic.gg");
    const std::string lastName="Game 256 "+std::string(83,'x')+".gg",lastPath="/VMS/GGVM/ROMS/"+lastName;assert(lastName.size()==95);files[lastPath]=sonic;
    for(unsigned i=256;i;i--){char name[32];snprintf(name,sizeof name,"Game %03u.gg",i);addDirectoryEntry(i==256?lastName:name,sonic.size());}
    addDirectoryEntry("Folder.gg",0,true);addDirectoryEntry("README.txt",0);VmFileInfo malformed{};memset(malformed.name,'x',sizeof malformed.name);directoryEntries.push_back(malformed);
    auto m=vm_entry(&h);assert(m&&ggvm::count==256&&!strstr(ggvm::message,"LIMITED"));turns(m,100);
    addDirectoryEntry("Game 257.gg",sonic.size());m=vm_entry(&h);assert(m&&ggvm::count==256&&strstr(ggvm::message,"FIRST 256 ROMS"));turns(m,100);
    assert(!strcmp(ggvm::entries[0].name,"Game 001.gg")&&ggvm::entries[255].name==lastName);
    const auto namesHash=vm_crc32(ggvm::entries,sizeof ggvm::entries);
    button(m,16);button(m,0);assert(ggvm::selected==255);button(m,32);button(m,0);assert(ggvm::selected==0);
    for(unsigned page=0;page<15;page++){button(m,128);button(m,0);}assert(ggvm::selected==255);
    button(m,64);button(m,0);assert(ggvm::selected==238);button(m,128);button(m,0);assert(ggvm::selected==255);
    for(unsigned launch=0;launch<2;launch++){
        button(m,1);button(m,0);assert(ggvm::game&&ggvm::cache.crc==vm_crc32(sonic.data(),sonic.size()));turns(m,1000);assert(!gg::error());
        const auto before=replacedCells;button(m,12);button(m,0);turns(m,100);
        assert(!ggvm::game&&!waiting&&ggvm::selected==255&&ggvm::count==256&&replacedCells-before==1000);
        assert(!memcmp(receivedMenu,ggvm::display.picker.cells,sizeof receivedMenu));
        assert(vm_crc32(ggvm::entries,sizeof ggvm::entries)==namesHash);
    }
    files.erase(lastPath);directoryEntries=original;
    puts("PASS 256-game picker: sorted full names, slot 256 launch, wrap/page navigation, 257th-file warning, ignored entries, full screen restoration and relaunch");
}
static void inputSoundTests(const VmModule*m){
    for(auto b:{uint8_t(129),uint8_t(67),uint8_t(0),uint8_t(8)}){VmInput older{uint8_t(b^1),0,0,0x83},latest{b,0,0,0x83};m->input(&older);m->input(&latest);
        for(unsigned i=0;i<300;i++){turns(m,1);assert((gg::readPort(0xdc)&16)==((b&1)?0:16));assert((gg::readPort(0xdc)&32)==((b&2)?0:32));assert((gg::readPort(0)&128)==((b&8)?0:128));}}
    button(m,0);uint8_t sound[26];gg::writePort(0x06,255);for(unsigned c=0;c<4;c++)gg::writePort(0x7f,0x9f|(c<<5));gg::sid(sound);for(unsigned v=0;v<3;v++)assert(!(sound[5+v*7]&1));
    gg::writePort(0x7f,0x80);gg::writePort(0x7f,16);gg::writePort(0x7f,0x90);gg::sid(sound);assert(sound[5]==0x41&&sound[7]==0xf0&&(sound[0]&1));gg::sid(sound);assert(!(sound[0]&1));
    gg::writePort(0x7f,0x9a);gg::sid(sound);gg::writePort(0x7f,0x90);gg::sid(sound);assert(sound[0]&1);
    gg::writePort(0x06,0);gg::sid(sound);for(unsigned v=0;v<3;v++)assert(!(sound[5+v*7]&1));gg::writePort(0x06,0x10);gg::sid(sound);assert(sound[5]&1);
    gg::writePort(0x06,255);gg::writePort(0x7f,0xe4);gg::writePort(0x7f,0xf0);gg::sid(sound);assert((sound[12]&0x81)==0x81||(sound[19]&0x81)==0x81);
    puts("PASS input/audio: current held state survives old FIFO samples, GG Start port, PSG latch/data/volume, SID retrigger on rise, stereo masks to mono, noise allocation");
}
static void speechBoundsTests(){
    struct Guarded {Sn76489 p;uint32_t guard;} test{};test.guard=0x12345678;
    auto &p=test.p;auto dc=[&](){psg_reset(&p,0,0);psg_write_io(&p,0x81,0);psg_write_io(&p,0xa1,0);psg_write_io(&p,0xc1,0);};
    dc();psg_write_io(&p,0xd4,100);psg_end_frame(&p,80000);assert(p.speech_state==0); // A volume setting is not a sample stream.
    dc();psg_end_frame(&p,3579545*9);for(int t=3579545*9;t<3579545*9+100000;t+=170)psg_write_io(&p,0xd7,t);assert(p.speech_state==3);
    dc();for(int t=100;t<3579545*3;t+=170)psg_write_io(&p,0xd0|((t/170)&15),t);psg_end_frame(&p,3579545*3+80000);
    assert(p.speech_state==3&&p.speech_count==16384&&test.guard==0x12345678);
    puts("PASS speech bounds: isolated volume writes ignored, boot window closes, oversized clips skipped without buffer overwrite");
}
static void cacheTests(VmHost &h){
    auto &rom=files["/VMS/GGVM/ROMS/banks.gg"];rom.resize(1048576);for(unsigned b=0;b<64;b++)memset(rom.data()+b*16384,b,16384);memcpy(rom.data()+0x7ff0,"TMR SEGA",8);rom[0x7fff]=0x72;
    const uint8_t boot[]={0x3e,63,0x32,0xff,0xff,0xc3,0,0x80},high[]={0x3e,0x5a,0x32,0,0xc0,0xc3,5,0x80};memcpy(rom.data(),boot,sizeof boot);memcpy(rom.data()+63*16384,high,sizeof high);
    gg::stop();ggvm::RomCache c;h.guest_ram_bytes=5*16384;assert(c.open(&h,"/VMS/GGVM/ROMS/banks.gg",rom.size()));auto first=c.page(0);assert(gg::start(first,c.size(),c.crc,{},{&c,ggvm::RomCache::readPage}));
    gg::run(1000);assert(gg::peek(0xc000)==0x5a); // Real Z80 instruction fetch from bank 63.
    for(unsigned b=0;b<64;b++){gg::poke(0xfffd,b);gg::poke(0xfffe,(b+1)&63);gg::poke(0xffff,(b+2)&63);assert(gg::peek(0x100)==0);assert(gg::peek(0x500)==b);assert(gg::peek(0x4100)==((b+1)&63));assert(gg::peek(0x8100)==((b+2)&63));}
    assert(c.misses>64);gg::poke(0xfffc,8);gg::poke(0x8000,0x42);gg::poke(0xfffc,12);gg::poke(0x8000,0x55);gg::poke(0xfffc,8);assert(gg::peek(0x8000)==0x42);gg::poke(0xfffc,12);assert(gg::peek(0x8000)==0x55);
    gg::poke(0xfffc,0);failRead=true;gg::poke(0xffff,30);assert(gg::error());failRead=false;c.close();gg::stop();h.guest_ram_bytes=524288;
    assert(!c.open(&h,"/VMS/GGVM/ROMS/banks.gg",1048577));auto oversized=rom;oversized.resize(2097152);files["/VMS/GGVM/ROMS/big.gg"]=oversized;assert(!c.open(&h,"/VMS/GGVM/ROMS/big.gg",2097152));
    std::vector<uint8_t> copier(512,0);copier.insert(copier.end(),rom.begin(),rom.end());files["/VMS/GGVM/ROMS/copier.gg"]=copier;assert(c.open(&h,"/VMS/GGVM/ROMS/copier.gg",copier.size()));assert(c.size()==1048576);auto crc=c.crc;c.close();assert(c.open(&h,"/VMS/GGVM/ROMS/copier.gg",copier.size())&&c.crc==crc);c.close();
    puts("PASS 1 MiB: all 64 banks, fixed 1 KiB, five-slot eviction/pinning, both SRAM banks, failed SD read, 2 MiB rejection, copier reload");
}
static void saveTests(VmHost &h){
    auto &s=ggvm::saves;gg::poke(0xfffc,8);gg::poke(0x8000,0x42);assert(s.flush());auto old=files;
    gg::poke(0x8000,0x43);failWrite=true;assert(!s.flush());failWrite=false;for(auto &[k,v]:old)if(k.find("/SAVES/")!=std::string::npos)assert(files[k]==v);
    failFlush=true;assert(!s.flush());failFlush=false;assert(s.flush());gg::saveData()[0]=0;ggvm::BatteryStore reload;assert(reload.load(&h,ggvm::cache.crc)&&gg::saveData()[0]==0x43);
    std::string newest;uint32_t seq=0;for(auto &[k,v]:files)if(k.find("/SAVES/")!=std::string::npos){uint32_t s;memcpy(&s,v.data()+12,4);if(s>seq){seq=s;newest=k;}}files[newest].back()^=1;
    assert(reload.load(&h,ggvm::cache.crc)&&gg::saveData()[0]==0x42);
    auto backup=files;for(auto &[k,v]:files)if(k.find("/SAVES/")!=std::string::npos)v[0]=0;assert(!reload.load(&h,ggvm::cache.crc));files=backup;
    gg::poke(0xfffc,0);puts("PASS battery: first save, write/flush failure preserves older generation, reload, corrupt newest fallback, both corrupt rejection");
}
int main(int argc,char**argv){assert(argc==3);output=argv[2];std::filesystem::create_directories(output);std::ifstream f(argv[1],std::ios::binary);assert(f);files["/VMS/GGVM/ROMS/Sonic.gg"]={std::istreambuf_iterator<char>(f),{}};
    addDirectoryEntry("Sonic.gg",files["/VMS/GGVM/ROMS/Sonic.gg"].size());
    memset(guest+524288,0xa5,32);auto h=makeHost();speechBoundsTests();cacheTests(h);pickerTests(h);
    const auto *m=vm_entry(&h);assert(m);turns(m,100);assert(!ggvm::game);button(m,8);button(m,0);assert(ggvm::game);turns(m,220000);snapshot("title.rgb332");assert(speechPlays==1);
    printf("PASS boot speech: %u packed bytes, %u samples at 8 kHz; held playback ACK freezes guest/video and resumes normally\n",speechTotal,speechTotal*2);
    auto t=gg::ticks();auto wall=now;button(m,8);button(m,0);turns(m,60000);snapshot("title.rgb332");
    button(m,8,1000);button(m,0);turns(m,40000);snapshot("level.rgb332");button(m,128|1,60000);button(m,0);turns(m,10000);snapshot("play.rgb332");
    assert(!gg::error()&&ggvm::game&&pictures>100);int64_t expected=uint64_t(now-wall)*gg::ClockHz/1000000;assert(int64_t(gg::ticks()-t)>expected-5000&&int64_t(gg::ticks()-t)<expected+5000);
    unsigned colors[256]{};for(auto p:ggvm::display.pixels)colors[p]++;unsigned distinct=0;for(auto n:colors)distinct+=n!=0;assert(distinct>4);
    inputSoundTests(m);auto tick=gg::ticks();button(m,12);button(m,0);turns(m,1000);assert(!ggvm::game&&!waiting);button(m,1);button(m,0);assert(ggvm::game);turns(m,1000);assert(gg::ticks()<tick);
    saveTests(h);gg::poke(0xfffc,8);gg::poke(0x8000,0x66);failWrite=true;button(m,12);button(m,0);assert(ggvm::saveBlocked&&!ggvm::game);assert(!ggvm::loadPath("/VMS/GGVM/ROMS/Sonic.gg",524288));failWrite=false;assert(!ggvm::loadPath("/VMS/GGVM/ROMS/Sonic.gg",524288));assert(!ggvm::saveBlocked);assert(ggvm::loadPath("/VMS/GGVM/ROMS/Sonic.gg",524288));assert(gg::saveData()[0]==0x66);
    button(m,12);button(m,0);assert(!ggvm::game);auto goodSaves=files;assert(!ggvm::loadPath("/VMS/GGVM/ROMS/missing.gg",524288));assert(ggvm::loadPath("/VMS/GGVM/ROMS/Sonic.gg",524288));assert(gg::saveData()[0]==0x66);
    for(auto &[k,v]:goodSaves)if(k.find("/SAVES/")!=std::string::npos)assert(files[k]==v);
    button(m,12);button(m,0);h.content_path="/VMS/GGVM/ROMS/Sonic.gg";m=vm_entry(&h);assert(m&&ggvm::game);turns(m,10000);assert(!gg::error());
    for(unsigned i=0;i<32;i++)assert(guest[524288+i]==0xa5);printf("PASS Sonic 2 / GGVM: direct + picker launch, Start, movement+fire, frozen frames, clock, return/relaunch, save retry; %u pictures, %u colors, core state %u bytes\n",pictures,distinct,gg::stateBytes());
}
