// SPDX-License-Identifier: MIT
#include "machine.h"
#include "core/sms.h"
#include "core/sms_internal.h"
#include <cstring>
extern "C" bool SMS_load_gg_paged(SMS_Core*,const uint8_t*,size_t,const uint8_t*(*)(void*,size_t),void*,uint32_t,int);
namespace gg {
static SMS_Core core;
static Video sink;static RomReader source;static const char *failure;
static bool running;static uint64_t elapsed;static unsigned frameCount;
static uint32_t observed[3];static uint8_t prevVolume[3],prevOwner[3];
// TotalSMS passes native 4-bit GG components, not 8-bit RGB.
static uint32_t colour(void*,uint8_t r,uint8_t g,uint8_t b){return ((r*7+7)/15<<5)|((g*7+7)/15<<2)|((b*3+7)/15);}
static void line(void*,unsigned y,const uint8_t*p){if(y>=24&&y<168&&sink.line)sink.line(sink.context,y-24,p+48);}
static void frame(void*,uint32_t){frameCount++;if(sink.frame)sink.frame(sink.context);}
static const uint8_t *page(void*,size_t offset){auto p=source.page(source.context,offset);if(!p)failure="ROM BANK READ FAILED";return p;}
void stop(){running=false;failure=nullptr;memset(&core,0,sizeof core);}
bool start(const uint8_t *first,size_t bytes,uint32_t crc,Video v,RomReader reader,int console){
    stop();sink=v;source=reader;elapsed=frameCount=0;memset(observed,0,sizeof observed);memset(prevVolume,0,sizeof prevVolume);memset(prevOwner,255,sizeof prevOwner);
    if(!reader.page||!SMS_init(&core))return false;
    SMS_set_userdata(&core,nullptr);SMS_set_colour_callback(&core,colour);SMS_set_vblank_callback(&core,frame);core.scanline_callback=line;
    SMS_set_use_exact_timing(&core,true);
    running=SMS_load_gg_paged(&core,first,bytes,page,nullptr,crc,console)&&!failure;return running;
}
void run(unsigned cycles){if(running&&!failure&&cycles){SMS_run(&core,int(cycles));elapsed+=cycles;if(core.cart.mappers.sega.fffc&0x93)failure="UNSUPPORTED MAPPER CONTROL";}}
void capture(bool enabled){core.skip_frame=!enabled;}
void buttons(uint8_t b){
    core.port.a=0xff;
    if(b&16)core.port.a&=~1;if(b&32)core.port.a&=~2;if(b&64)core.port.a&=~4;if(b&128)core.port.a&=~8;
    if(b&1)core.port.a&=~16;if(b&2)core.port.a&=~32;
    if(b&8)core.port.gg_regs[0]&=~128;else core.port.gg_regs[0]|=128;
}
bool pinned(const uint8_t *bank,size_t bytes){auto a=reinterpret_cast<uintptr_t>(bank);for(auto p:core.rmap){auto x=reinterpret_cast<uintptr_t>(p);if(x>=a&&x-a<bytes)return true;}return false;}
const char *error(){return failure;}uint64_t ticks(){return elapsed;}unsigned frames(){return frameCount;}
uint8_t peek(uint16_t addr){return SMS_read8(&core,addr);}void poke(uint16_t addr,uint8_t value){SMS_write8(&core,addr,value);}
uint8_t readPort(uint8_t port){return SMS_read_io(&core,port);}void writePort(uint8_t port,uint8_t value){SMS_write_io(&core,port,value);}
uint8_t *saveData(){return &core.cart_ram.ram[0][0];}unsigned saveBytes(){return SaveBytes;}
uint32_t saveRevision(){return SMS_crc32(saveData(),SaveBytes);}unsigned stateBytes(){return sizeof core;}
unsigned speechBytes(){return core.psg&&core.psg->speech_state==2?core.psg->speech_count/2:0;}
const uint8_t *speechData(){return core.psg?core.psg->speech:nullptr;}
void speechConsumed(){if(core.psg)core.psg->speech_state=3;}
void sid(uint8_t out[26],uint32_t clock){
    memset(out,0,26);if(!running||failure)return;const auto &p=*core.psg;
    if(p.speech_state==2||(p.speech_state==1&&p.speech_writes>=16))return;
    uint8_t level[4];const uint8_t amplitude[16]={15,12,10,8,6,5,4,3,2,2,1,1,1,1,1,0};
    for(unsigned c=0;c<4;c++)level[c]=(p.stereo&((1<<c)|(16<<c)))?amplitude[p.volume[c]]:0;
    // Sega periods 0/1 are DC, not audible SID oscillators.
    for(unsigned c=0;c<3;c++)if(p.tone[c]<=1)level[c]=0;
    unsigned stolen=2;if(level[3]){if(level[0]<level[stolen])stolen=0;if(level[1]<level[stolen])stolen=1;}
    for(unsigned voice=0;voice<3;voice++){
        unsigned owner=level[3]&&voice==stolen?3:voice;unsigned vol=level[owner];uint32_t period;
        if(owner==3)period=(p.noise&3)==3?32u*(p.tone[2]?p.tone[2]:1024):512u<<(p.noise&3);
        else period=32u*(p.tone[owner]?p.tone[owner]:1024);
        uint64_t word=(uint64_t(ClockHz)<<24)/(uint64_t(period)*clock);if(word>65535)word=65535;
        uint8_t *s=out+1+voice*7;s[0]=word;s[1]=word>>8;s[2]=0;s[3]=8;s[4]=(owner==3?0x80:0x40)|(vol?1:0);s[5]=0;s[6]=vol<<4;
        if(vol&&(p.trigger[owner]!=observed[voice]||vol>prevVolume[voice]||owner!=prevOwner[voice]))out[0]|=1<<voice;
        observed[voice]=p.trigger[owner];prevVolume[voice]=vol;prevOwner[voice]=owner;
    }
    out[25]=15;
}
}
