// SPDX-License-Identifier: MIT
#pragma once
#include <cstring>
#include <cstdio>
// 16 KiB pages of the SD ROM; mapped CPU pages and bank zero cannot be evicted.
class RomCache {
    const VmHost *host=nullptr;uint32_t handle=0,bytes=0,offset=0,clock=0;
    uint8_t *memory=nullptr;unsigned slots=0;int tag[32];uint32_t age[32];
public:
    uint32_t crc=0,misses=0,hits=0,readMicros=0;const char *failure=nullptr;
    void close(){if(handle&&host)host->close(handle);handle=0;}
    bool open(const VmHost*h,const char*path,unsigned expected){
        close();host=h;failure=nullptr;VmFileInfo info{};handle=h->open(path,&info);
        if(!handle||info.directory||info.bytes!=expected){failure="ROM MISSING OR CHANGED";close();return false;}
        offset=(expected&16383)==512?512:0;bytes=expected-offset;
        if(bytes<32768||bytes>gg::MaxRomBytes||(bytes&(bytes-1))){failure="ROM MUST BE 32 KIB TO 1 MIB";close();return false;}
        memory=h->guest_ram;slots=h->guest_ram_bytes/16384;if(slots>32)slots=32;
        if(slots<5){failure="NOT ENOUGH ROM CACHE MEMORY";close();return false;}
        // Hash sequentially before running the core. No commercial ROM enters a release ZIP.
        uint32_t c=0xffffffff;
        for(uint32_t pos=0;pos<bytes;pos+=4096){if(h->read(handle,offset+pos,memory,4096)!=4096){failure="ROM READ FAILED";close();return false;}
            for(unsigned i=0;i<4096;i++){c^=memory[i];for(unsigned b=0;b<8;b++)c=(c>>1)^((c&1)?0xedb88320:0);}}
        crc=~c;clock=misses=hits=readMicros=0;for(unsigned i=0;i<32;i++){tag[i]=-1;age[i]=0;}
        // Require an actual Sega header for initial supported GG cartridges.
        auto p=page(0x7ff0);if(!p){close();return false;}
        if(memcmp(p,"TMR SEGA",8)||((p[15]>>4)<5)||((p[15]>>4)>7)){failure="NOT A SUPPORTED GAME GEAR ROM";close();return false;}
        return true;
    }
    const uint8_t *page(size_t addr){
        if(failure||!handle||addr>=bytes){failure="ROM BANK OUT OF RANGE";return nullptr;}
        unsigned bank=unsigned(addr/16384),chosen=slots;
        for(unsigned i=0;i<slots;i++)if(tag[i]==int(bank)){hits++;age[i]=++clock;return memory+i*16384+(addr&16383);}
        for(unsigned i=0;i<slots;i++)if(tag[i]<0){chosen=i;break;}
        if(chosen==slots){uint32_t oldest=~0u;for(unsigned i=0;i<slots;i++)if(tag[i]!=0&&!gg::pinned(memory+i*16384,16384)&&age[i]<=oldest){oldest=age[i];chosen=i;}}
        if(chosen==slots){failure="ROM CACHE HAS NO FREE BANK";return nullptr;}
        tag[chosen]=-1;auto begin=host->micros_now();auto got=host->read(handle,offset+bank*16384,memory+chosen*16384,16384);readMicros+=host->micros_now()-begin;
        if(got!=16384){failure="ROM BANK READ FAILED";return nullptr;}
        tag[chosen]=bank;age[chosen]=++clock;misses++;return memory+chosen*16384+(addr&16383);
    }
    unsigned size() const{return bytes;}
    int console(){auto p=page(0x7ff0);return p&&(p[15]>>4)==5?1:0;}
    static const uint8_t *readPage(void*context,size_t addr){return static_cast<RomCache*>(context)->page(addr);}
};
