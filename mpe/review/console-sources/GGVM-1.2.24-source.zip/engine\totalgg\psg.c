// SPDX-License-Identifier: MIT
#include "sn76489.h"
#include <string.h>
static Sn76489 chip;
enum {SpeechIdle,SpeechRecording,SpeechReady,SpeechDone};
static unsigned period(Sn76489*p){p->speech_phase+=3545;unsigned n=447;if(p->speech_phase>=8000){p->speech_phase-=8000;n++;}return n;}
static void finish_speech(Sn76489*p){
    if(p->speech_writes<16||p->speech_count<256){p->speech_state=SpeechIdle;return;}
    if(p->speech_count&1){unsigned n=p->speech_count;p->speech[n/2]=(p->speech[n/2]&0xf0)|(p->speech[n/2]>>4);p->speech_count++;}
    p->speech_state=SpeechReady;
}
static void advance_speech(Sn76489*p,uint32_t time){
    if(p->speech_state!=SpeechRecording)return;
    const uint32_t end=p->speech_last+71591; // End after 20 ms without a volume write.
    const uint32_t until=time<end?time:end;
    while(p->speech_cursor<until){
        const uint32_t stop=until<p->speech_next?until:p->speech_next;
        p->speech_area+=(stop-p->speech_cursor)*(15-p->volume[2]);p->speech_cursor=stop;
        if(stop==p->speech_next){
            if(p->speech_count==sizeof(p->speech)*2){p->speech_state=SpeechDone;return;} // Oversized clips are skipped.
            const unsigned width=stop-p->speech_start,sample=(p->speech_area+width/2)/width,n=p->speech_count++;
            if(n&1)p->speech[n/2]|=sample;else p->speech[n/2]=sample<<4;
            p->speech_area=0;p->speech_start=stop;p->speech_next+=period(p);
        }
    }
    if(time>=end)finish_speech(p);
}
void psg_update_timestamp(Sn76489*p,int t){if(p->speech_state==SpeechRecording){p->speech_last+=t;p->speech_cursor+=t;p->speech_next+=t;p->speech_start+=t;}}
void psg_end_frame(Sn76489*p,int t){advance_speech(p,(uint32_t)t);if(p->speech_state==SpeechIdle&&t>3579545*8)p->speech_state=SpeechDone;}
Sn76489* psg_init(double clock,unsigned rate){(void)clock;(void)rate;psg_reset(&chip,0,0);return &chip;}
void psg_reset(Sn76489*p,int taps,int feed){(void)taps;(void)feed;memset(p,0,sizeof(*p));memset(p->volume,15,4);p->stereo=255;}
void psg_write_io(Sn76489*p,uint8_t v,int time){
    advance_speech(p,(uint32_t)time);if(v&128)p->latch=(v>>4)&7;
    unsigned c=p->latch>>1;
    if(p->latch&1){uint8_t vol=v&15;if(vol<p->volume[c])p->trigger[c]++;p->volume[c]=vol;}
    else if(c==3){p->noise=v&7;p->trigger[3]++;}
    else if(v&128)p->tone[c]=(p->tone[c]&0x3f0)|(v&15);
    else p->tone[c]=(p->tone[c]&15)|((v&63)<<4);
    const int dc=p->tone[0]==1&&p->tone[1]==1&&p->tone[2]==1&&p->volume[3]==15&&(p->stereo&0x44);
    if(p->speech_state==SpeechRecording&&!dc)finish_speech(p);
    if(dc&&p->latch==5&&(p->speech_state==SpeechIdle||p->speech_state==SpeechRecording)){
        if(p->speech_state==SpeechIdle){
            p->speech_state=SpeechRecording;p->speech_count=p->speech_writes=p->speech_area=p->speech_phase=0;
            p->speech_cursor=p->speech_start=(uint32_t)time;p->speech_next=(uint32_t)time+period(p);
        }
        p->speech_last=(uint32_t)time;p->speech_writes++;
    }
}
void psg_gg_write_io(Sn76489*p,uint8_t v,int time){(void)time;p->stereo=v;}
