// GGVM runtime ZIP plus separate corresponding-source/rebuild evidence.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import assert from 'node:assert/strict';import {spawnSync} from 'node:child_process';
import {packageVmSource} from './package-vm-source.mjs';
const root=path.resolve(import.meta.dirname,'..'),out=path.resolve(process.argv[2]??'build/gg-package');
assert.ok(!fs.existsSync(out),'Choose a fresh output directory');
const source=path.join(out,'source'),sd=path.join(out,'SD'),pkg=path.join(sd,'VMS/GGVM');fs.mkdirSync(pkg,{recursive:true});
const inputs=['engine/totalgg','vm/gg','vm/abi','vm/video','vm/client','vm/nes/font8x8.h','nes/tools/nes_terminal.mjs','nes/tools/build_nesvm_cartridge.mjs','Source/Teensy/MinimalBoot/Common/VMABI.h','scripts/build-gg-core.mjs','scripts/package-ggvm.mjs','scripts/verify-ggvm.mjs','vm/tests/gg_module_test.cpp','vm/tests/gg_client_test.mjs','vm/tests/helpers','vms/GGVM/README.md','vms/GGVM/NOTICES.md','engine/gnuboy/COPYING','sms/GGVM.md'];
inputs.push('vm/tests/gg_speech_test.mjs','vm/tests/gg_speech_vice.mjs');
inputs.push('scripts/package-vm-source.mjs');
for(const rel of inputs){
  const to=path.join(source,rel);fs.mkdirSync(path.dirname(to),{recursive:true});
  // This F1 client does not use the separate proprietary renderer adapter.
  fs.cpSync(path.join(root,rel),to,{recursive:true,filter:file=>path.relative(root,file).replaceAll('\\','/')!=='vm/client/host/native-prism-plus-client.mjs'});
}
const prefix=process.env.MPE_ARM_PREFIX??path.join(root,'build/toolchain/Arduino15/packages/teensy/tools/teensy-compile/11.3.1/arm/bin/arm-none-eabi-');
const env={...process.env,MPE_ARM_PREFIX:prefix,PATH:'C:/msys64/mingw64/bin;'+process.env.PATH};
const run=(exe,args,cwd=source)=>{const r=spawnSync(exe,args,{cwd,env,encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});if(r.error||r.status)throw Error((r.error??'')+'\n'+r.stdout+r.stderr);return r.stdout;};
const node=(script,args)=>run(process.execPath,[path.join(source,script),...args]);const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const version='1.2.24';
console.log(node('scripts/build-gg-core.mjs',[path.join(out,'core')]).trim());
console.log(node('vm/gg/build-client.mjs',['--output-prg',path.join(out,'ggvm.prg'),'--output-boot-bank',path.join(out,'boot.bin'),'--manifest',path.join(out,'client.json')]).trim());
console.log(node('vm/tests/gg_client_test.mjs',[out]).trim());
node('nes/tools/build_nesvm_cartridge.mjs',['--id','GGVM','--boot-bank',path.join(out,'boot.bin'),'--output',path.join(pkg,'client.crt'),'--manifest',path.join(out,'cartridge.json')]);
fs.copyFileSync(path.join(out,'core/engine.mvm'),path.join(pkg,'engine.mvm'));fs.copyFileSync(path.join(pkg,'client.crt'),path.join(sd,'GGVM.crt'));
fs.writeFileSync(path.join(pkg,'manifest.vmi'),'VM1\nGGVM\ngg\nengine.mvm\nclient.crt\nEND\n');
for(const name of ['README.md','NOTICES.md'])fs.copyFileSync(path.join(source,'vms/GGVM',name),path.join(pkg,name));
for(const name of ['LICENSE-TotalSMS.txt','LICENSE-scheduler.txt'])fs.copyFileSync(path.join(source,'engine/totalgg',name),path.join(pkg,name));
fs.copyFileSync(path.join(source,'engine/gnuboy/COPYING'),path.join(pkg,'LICENSE-GPL-2.0.txt'));
fs.writeFileSync(path.join(pkg,'BUILD.json'),JSON.stringify({name:'GGVM',version,minimumFirmwareVersion:'1.1.13',recommendedTravisFirmwareVersion:'1.2.24',compatibleGuiFirmwareVersion:'1.2.23',fix:'Defer startup SID until the first video resume or picker BASE_COMPLETE is acknowledged',physicalHardware:false},null,2)+'\n');
fs.mkdirSync(path.join(pkg,'ROMS'));fs.writeFileSync(path.join(pkg,'ROMS/README.txt'),'Place your own .gg cartridges here, 32 KiB through 1 MiB. No games are included.\n');fs.mkdirSync(path.join(pkg,'SAVES'));
node('scripts/build-gg-core.mjs',[path.join(out,'relink')]);assert.equal(sha(fs.readFileSync(path.join(out,'relink/engine.mvm'))),sha(fs.readFileSync(path.join(pkg,'engine.mvm'))),'Corresponding-source rebuild differs');
const correspondingSource=packageVmSource(source,out,'GGVM',version);
const files=[];function walk(dir,rel=''){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name),name=rel+e.name;if(e.isDirectory())walk(p,name+'/');else{assert.ok(!/\.(gg|sms|gb|gbc|nes|sav|s[01]|pcm4|wav)$/i.test(name));files.push({path:name,sha256:sha(fs.readFileSync(p))});}}}walk(sd);files.sort((a,b)=>a.path.localeCompare(b.path));
assert.ok(!files.some(f=>f.path.split('/').some(p=>p.toUpperCase()==='SOURCE')));const zip=path.join(out,'GGVM.zip');const quote=s=>s.replaceAll("'","''");
const rows=JSON.parse(run('powershell.exe',['-NoProfile','-NonInteractive','-Command',`
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory('${quote(sd)}','${quote(zip)}')
$ggArchive=[IO.Compression.ZipFile]::OpenRead('${quote(zip)}');$ggHash=[Security.Cryptography.SHA256]::Create()
try {$ggRows=@(foreach($entry in $ggArchive.Entries){if($entry.Name){$stream=$entry.Open();try{$digest=[BitConverter]::ToString($ggHash.ComputeHash($stream)).Replace('-','').ToLowerInvariant()}finally{$stream.Dispose()};[pscustomobject]@{path=$entry.FullName.Replace([char]92,[char]47);sha256=$digest}}});ConvertTo-Json -InputObject $ggRows -Compress}finally{$ggArchive.Dispose();$ggHash.Dispose()}
`]));assert.deepEqual(rows.sort((a,b)=>a.path.localeCompare(b.path)),files);
const report={name:'GGVM',version,release:'gg-direct-startup',minimumFirmwareVersion:'1.1.13',recommendedTravisFirmwareVersion:'1.2.24',abi:2,maxGames:256,maxRomBytes:1048576,romCacheBytes:524288,bootSpeech:{rate:8000,bits:4,bufferBytes:8192,packetType:6,requiresMatchedClient:true},physicalAcceptance:false,correspondingSourceRebuild:true,correspondingSource,memory:JSON.parse(fs.readFileSync(path.join(out,'core/memory.json'))),files,download:{file:'GGVM.zip',bytes:fs.statSync(zip).size,sha256:sha(fs.readFileSync(zip))}};
fs.writeFileSync(path.join(out,'checksums.json'),JSON.stringify(report,null,2)+'\n');console.log('Verified GGVM module, client, source rebuild and runtime ZIP: '+zip);
