# GGVM implementation and validation

Updated 2026-09-07. Game Gear is now implemented as an independent **GGVM**
candidate; the broader SMSVM plan in [README.md](README.md) remains future work.
The user's 1 MiB cartridge target replaces the initial 256 KiB planning cap.

GGVM uses the MIT TotalSMS Z80/VDP core with its own bounded SD ROM reader,
native-height 160x144 F1 output, current held-input client, PSG/SID adapter and
alternating battery saves. [Provenance](../engine/totalgg/UPSTREAM.md) records
the exact core and scheduler revisions. No firmware engine branch was added.

The source baseline is MPE V1.1.13 / `bd6a5c7`. Other work in this checkout is
concurrent. GGVM uses ABI 2 profile 0, existing service bits 127 and the host
prefix through `video_indexed`; it does not require the concurrent RAM1_AUX
extension. A small shared terminal-overlay compatibility change accepts either
the original keyboard emitter signature or its optional mouseRelative argument.
It does not change the emitted controller policy.

## Build and local test

```powershell
node scripts/verify-ggvm.mjs "E:\OneDrive\Desktop\GameGear\Sonic The Hedgehog 2 (World).gg" build/gg-test
node scripts/package-ggvm.mjs build/gg-package
```

The verifier uses the existing MinGW compiler for host tests. The package uses
the pinned ARM compiler under build/toolchain and Node.js. It builds only GGVM,
checks link bounds/unresolved symbols/heap use, rebuilds from a captured source
snapshot, and compares the module bytes. It validates ZIP members and rejects
game files. Local game checks read the supplied ROM; the runtime ZIP has none.

## Memory and cartridge behavior

The first measured ARM link fits the normal 96 KiB code and 192 KiB module-data
windows. The final exact sizes are in the package build's `core/memory.json`.
RAM1 contains the 96 KiB-class core state (including work/video/cart RAM), one
23,040-byte output frame, 24,576-byte indexed-video workspace, picker/packet
state and bounded input queues. The 256-entry picker retains full 95-character
filenames. Its current and previous screen cells share storage with the output
frame: packets finish before launch, and returning replaces every picker cell.
The PSG backend has an additional fixed 8 KiB boot-speech buffer.
The remaining workspace is reserved headroom;
the shared 48 KiB stack is separate. No PSRAM or heap allocation is linked.

RAM2 provides 32 cache slots of 16 KiB. The cache pins ROM bank zero and every
bank referenced by the CPU's page map. A miss evicts only an unreferenced bank,
reads a full replacement, and updates its tag only after a complete read.
Failures latch a readable error and stop the guest. The 1 MiB limit means 64
cartridge banks; it is independent of the 512 KiB cache allocation.

On small caches the same mapping stays valid; tests use only five slots to
force eviction while changing all three windows. Program execution from bank
63 proves instruction fetch beyond the cache capacity, in addition to mapper
read checks. Sonic 2 is 512 KiB and can become fully resident after cold misses.

Only supported power-of-two sizes 32 KiB..1 MiB are accepted. Copier-header
offsets are per load. The normalized content CRC identifies saves; the exact
local Sonic 2 SHA-256 is
`2826d679932566411003334cd4b9d8b3618248b6693e98822f5b2425430623e0`.
Known non-Sega mappers or non-GG profiles in the upstream database are rejected.
Unknown cartridges with valid GG headers use the Sega profile and need their
own compatibility test. Rare Sega control modes outside the supported mapping
produce an error. No claim covers all 1 MiB games or every mapper.

## Verification evidence and remaining physical gate

The picker test enumerates 256 cartridges, sorts full filenames, launches slot
256, navigates across pages and wraps, reports a 257th cartridge, and checks
complete screen restoration and relaunch after reusing the display buffer.

The host test runs the actual adapter and core with the supplied Sonic 2 file,
starts the game, reaches Underground Zone Act 1 and applies movement/fire.
It checks clock accounting, direct and picker launches, return/relaunch,
held/released input despite queued stale samples, frozen pictures during Busy,
PSG/SID register behavior and guarded guest-memory bounds. Source-frame PNGs
and shared-converter C64 previews are generated under `build/gg-test`.

Battery tests cover first save, both SRAM banks, write and flush failures,
newest-slot corruption fallback, both-slot rejection, retry before switching,
and preservation when a subsequent ROM load fails. This is storage-model
evidence, not a power-loss test on physical SD media.

The generated-client test runs the exact GGVM PRG through the functional C64
CPU helper. It covers idle input, Return/Space/fire, shifted cursors, the menu
chord, simultaneous buttons, release and immutable retries. Shared packet
recovery tests exercise the receiver's CRC/retransmission behavior separately.

Hardware testing remains required: TeensyROM+ Fab 0.4 / Teensy 4.1 / NTSC C64,
exact firmware/module/client/ROM hashes, guest speed versus wall time, picture
cadence, controller latency, SID quality, cache misses/read delays, save/reboot
and an extended session. PAL and C128 in C64 mode require separate results.
Hardware acceptance and public release remain pending. This candidate is kept
in the private development repository; firmware and other VM packages are
outside the GGVM change.

## Boot speech candidate

The supplied Sonic 2 starts its voice around 2.48 emulated seconds. It writes
matching attenuation values to three DC tone channels at approximately 21 kHz
for 1.515 seconds. The backend averages channel 3's inverted attenuation codes
over 8 kHz time windows and packs two 4-bit samples per byte. It retains 20 ms
after the last volume write, producing 6,141 bytes / 12,282 samples in this ROM.
This interprets the game's simple PCM encoding; it does not model the PSG's
nonlinear analogue volume response or mix arbitrary channels.

One qualifying clip is allowed during the first eight emulated seconds. Tiny
volume-setting bursts are ignored; capture overflow skips the clip. After
capture, guest progress stops while the prior picture finishes. Packet type 6
then sends begin (version 1, rate 0 = 8 kHz, LE16 byte count), contiguous data
(LE16 offset plus up to 226 packed bytes), and play (LE16 complete byte count).
Flags 0/1/2 identify these operations. Existing packet CRC/replay remains in use.

The GGVM-only client reserves $8000-$9fff, free in its F1 display profile.
Begin/data/play sizes, offsets and completeness are checked before playback.
It holds the play packet's ACK until the whole clip finishes. The module stops
all guest/video work during this interval, including pump calls while pending.
It resets its wall-clock baseline after ACK, so playback does not cause a burst
of game catch-up. This initial implementation adds buffering delay at boot.

The client polls CIA1 Timer A with interrupts masked, using reload 127 on NTSC
and 122 on PAL. Three SID pulse/TEST voices provide the DC offset for volume
playback, including 8580 support. The timer stops and all SID registers clear
before returning; the following ordinary SID packet restores current music.
Keyboard input resumes after the bounded clip. No firmware API change is used.

Run `node vm/tests/gg_speech_vice.mjs build/gg-test-speech` after the ordinary
verifier to execute the exact player and ROM-derived clip independently in
VICE. WAVs and source PCM stay under ignored build output. Functional checks
cover sample identity, PAL/NTSC setup, corrupt-packet replay, incomplete/invalid
transfers, both buffer limits, held ACK behavior and music restoration. Physical
SID loudness, intelligibility and end-to-end timing still need acceptance.
