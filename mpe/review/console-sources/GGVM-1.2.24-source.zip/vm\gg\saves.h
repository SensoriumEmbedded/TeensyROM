// SPDX-License-Identifier: MIT
#pragma once
// A/B battery generations, explicit six-word little-endian format. No raw core state.
class BatteryStore {
    const VmHost *host=nullptr;char directory[320],path[352];
    uint32_t identity=0,serial=0,saved=0;int active=-1;bool enabled=false;
    static uint32_t crcUpdate(uint32_t c,const uint8_t*p,unsigned n){for(unsigned i=0;i<n;i++){c^=p[i];for(unsigned b=0;b<8;b++)c=(c>>1)^((c&1)?0xedb88320:0);}return c;}
    void filename(unsigned slot){snprintf(path,sizeof path,"%s/%08lx.s%u",directory,(unsigned long)identity,slot);}
    bool readSlot(unsigned slot,uint32_t &sequence,uint32_t &crc,bool &exists,bool restore=false){
        filename(slot);VmFileInfo info{};auto f=host->open(path,&info);exists=f&&(info.directory||info.bytes);if(!f)return false;
        uint32_t header[6]{};bool ok=!info.directory&&info.bytes==24+gg::SaveBytes&&host->read(f,0,header,24)==24&&header[0]==0x31534747&&header[1]==identity&&header[2]==gg::SaveBytes&&vm_crc32(header,20)==header[5];
        uint32_t c=0xffffffff;uint8_t chunk[1024];
        for(unsigned pos=0;ok&&pos<gg::SaveBytes;pos+=sizeof chunk){ok=host->read(f,24+pos,chunk,sizeof chunk)==sizeof chunk;if(ok){c=crcUpdate(c,chunk,sizeof chunk);if(restore)memcpy(gg::saveData()+pos,chunk,sizeof chunk);}}
        host->close(f);sequence=header[3];crc=header[4];return ok&&~c==crc;
    }
public:
    bool load(const VmHost*h,uint32_t crc){
        host=h;identity=crc;serial=0;active=-1;enabled=false;
        if(snprintf(directory,sizeof directory,"%s/SAVES",host->package_root)>=(int)sizeof directory)return false;
        bool found=false;for(unsigned i=0;i<2;i++){uint32_t seq=0,c=0;bool exists=false;if(readSlot(i,seq,c,exists)&&(active<0||int32_t(seq-serial)>0)){active=i;serial=seq;}found|=exists;}
        if(found&&active<0)return false;
        if(active>=0){uint32_t seq,c;bool exists;if(!readSlot(active,seq,c,exists,true))return false;}
        saved=gg::saveRevision();enabled=true;return true;
    }
    bool dirty()const{return enabled&&gg::saveRevision()!=saved;}
    bool flush(){
        if(!dirty())return true;
        VmFileInfo info{};auto d=host->open(directory,&info);if(d){host->close(d);if(!info.directory)return false;}
        else{VmFsRequest r{VmFsOp::Mkdir,0,1,0,directory,nullptr};if(host->file_op(&r))return false;}
        const unsigned slot=active<0?0:1-active;filename(slot);auto f=host->open_flags(path,VM_OPEN_WRITE|VM_OPEN_CREATE|VM_OPEN_TRUNCATE,&info);if(!f)return false;
        uint32_t header[6]={0x31534747,identity,gg::SaveBytes,serial+1,gg::saveRevision(),0};header[5]=vm_crc32(header,20);uint32_t invalid[6]{};
        bool ok=host->write(f,0,invalid,24)==24;
        for(unsigned pos=0;ok&&pos<gg::SaveBytes;pos+=1024)ok=host->write(f,24+pos,gg::saveData()+pos,1024)==1024;
        if(ok)ok=host->write(f,0,header,24)==24;
        VmFsRequest r{VmFsOp::Flush,f,0,0,nullptr,nullptr};if(ok)ok=host->file_op(&r)==0;r.operation=VmFsOp::Close;if(host->file_op(&r))ok=false;
        uint32_t seq=0,crc=0;bool exists=false;if(!ok||!readSlot(slot,seq,crc,exists)||seq!=header[3]||crc!=header[4])return false;
        active=slot;serial=seq;saved=crc;return true;
    }
};
