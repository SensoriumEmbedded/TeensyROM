// SPDX-License-Identifier: GPL-2.0-or-later
// GGVM adapter derived from GBVM: core and cartridges supplied by TotalSMS.
#include "../abi/vm_abi.h"
#include "../video/mpe_video_live.h"
#include "../../engine/totalgg/machine.h"
#include "../../engine/totalgg/core/sms_rom_database.h"
#include "../../engine/totalgg/core/sms_types.h"
#define PROGMEM
#include "../nes/font8x8.h"
#undef PROGMEM
#include <cstring>
#include <cstdio>
namespace ggvm {
#include "rom_cache.h"
#include "saves.h"
static RomCache cache;
static const VmHost *host;
static BatteryStore saves;
static uint32_t nextSave;
static bool saveBlocked;
struct Entry {char name[96];uint32_t bytes;};
static constexpr unsigned MaxGames=256;
static Entry entries[MaxGames];static unsigned count,selected;
static char directory[256],message[41];
alignas(4) static uint8_t videoWorkspace[VM_INDEXED_VIDEO_WORKSPACE_BYTES];
// Picker packets finish before launch; returning to the picker replaces every
// cell. Its current/previous screens can therefore share the guest-frame RAM.
static union {
    uint8_t pixels[160*144];
    struct {uint8_t cells[1000][10],presented[1000][10];} picker;
} display;
static uint8_t palette[256*3];
static uint16_t colorCount=256;
static bool game,ready,capturing,pending,frameEnd,menuDirty,replace,hires;
static bool videoSubmitted,displayEstablished;
static uint32_t generation,lastMicros,remainder,readyMicros;
static int64_t debt;
static uint8_t latestSid[26],sentSid[26];
static unsigned speechStage,speechOffset;
static unsigned cursor,pendingCount,pendingCells[19];
static VmPacket inFlight;
static VmInput inputs[32];static unsigned head,tail;static uint8_t previous,latestButtons;
static int compare(const char *a,const char *b){
    for(;;a++,b++){unsigned x=*a,y=*b;if(x>='A'&&x<='Z')x+=32;if(y>='A'&&y<='Z')y+=32;if(x!=y)return x<y?-1:1;if(!x)return 0;}
}
static bool romName(const char *n){auto e=strrchr(n,'.');return e&&!compare(e,".gg");}
static void say(const char *s){snprintf(message,sizeof message,"%s",s);menuDirty=true;}
static void text(unsigned row,unsigned column,const char *s,bool inverse=false){
    for(unsigned x=column;*s&&x<40;x++,s++){auto cell=display.picker.cells[row*40+x];unsigned ch=(uint8_t)*s;if(ch>127)ch='?';
        for(unsigned y=0;y<8;y++)cell[y]=MPE5Font8x8[ch][y]^(inverse?255:0);cell[8]=0x10;cell[9]=1;}
}
static void buildMenu(){
    for(unsigned i=0;i<1000;i++){memset(display.picker.cells[i],0,8);display.picker.cells[i][8]=0x10;display.picker.cells[i][9]=1;}
    text(0,6,"MHS GGVM - SEGA GAME GEAR");
    char status[41];snprintf(status,sizeof status,"ROM %u OF %u",count?selected+1:0,count);text(2,1,status);
    unsigned page=(selected/17)*17;
    for(unsigned i=0;i<17&&page+i<count;i++){char name[39];snprintf(name,sizeof name,"%c %.36s",page+i==selected?'>':' ',entries[page+i].name);text(i+4,1,name,page+i==selected);}
    text(22,0,message);text(23,0,"TOTALSMS CORE - SEE LICENSE NOTICES");text(24,0,"FIRE:RUN  SHIFT+RETURN:RETURN TO PICKER");
    cursor=0;ready=true;menuDirty=false;hires=true;
}
static void enumerate(){
    count=selected=0;VmFileInfo info{};auto dir=host->open(directory,&info);
    if(!dir||!info.directory){if(dir)host->close(dir);say("ROM DIRECTORY NOT FOUND");return;}
    int result;unsigned omitted=0;
    while((result=host->next(dir,&info))==1){
        if(info.directory||!memchr(info.name,0,sizeof info.name)||!romName(info.name))continue;
        if(count==MaxGames){omitted++;continue;}strcpy(entries[count].name,info.name);entries[count++].bytes=info.bytes;
    }
    host->close(dir);
    for(unsigned i=1;i<count;i++)for(unsigned j=i;j&&compare(entries[j].name,entries[j-1].name)<0;j--){auto t=entries[j];entries[j]=entries[j-1];entries[j-1]=t;}
    if(result<0)say("ROM LIST READ FAILED");
    else if(!count)say("ADD .GG FILES TO GGVM/ROMS");
    else if(omitted){char limit[41];snprintf(limit,sizeof limit,"LIST LIMITED TO FIRST %u ROMS",MaxGames);say(limit);}
    else say("FIRE OR RETURN RUNS THE SELECTED ROM");
}
static void line(void *,unsigned y,const uint8_t *src){if(capturing&&y<144)memcpy(display.pixels+y*160,src,160);}
static void frame(void *){
    if(capturing){ready=true;capturing=false;gg::capture(false);generation++;readyMicros=host->micros_now();}
    else if(!ready){capturing=true;gg::capture(true);}
}
static bool loadPath(const char *path,uint32_t expected){
    if(!saves.flush()){say("SAVE FAILED - FIRE RETRIES; KEEP POWER ON");saveBlocked=true;return false;}
    if(saveBlocked){saveBlocked=false;say("SAVE RECOVERED - FIRE TO RUN ROM");return false;}
    // Once the previous save is safe, detach its identity before replacing RAM.
    game=capturing=false;saves={};gg::stop();
    if(!cache.open(host,path,expected)){say(cache.failure);return false;}
    RomEntry entry{};
    if(rom_database_find_entry(&entry,cache.crc)&&(entry.sys!=SMS_System_GG||entry.map!=MAPPER_TYPE_SEGA)){
        cache.close();say("UNSUPPORTED CARTRIDGE MAPPER");return false;}
    auto first=cache.page(0);int console=cache.console();
    if(!first||!gg::start(first,cache.size(),cache.crc,{nullptr,line,frame},{&cache,RomCache::readPage},console)){
        say(cache.failure?cache.failure:"CORE START FAILED");cache.close();return false;}
    if(!saves.load(host,cache.crc)){say("SAVE READ FAILED - RESTORE SAVE BACKUP");cache.close();return false;}
    game=capturing=true;ready=videoSubmitted=false;gg::capture(true);generation=0;
    speechStage=speechOffset=0;
    memset(display.pixels,0,sizeof display.pixels);memset(latestSid,0,sizeof latestSid);memset(sentSid,0,sizeof sentSid);
    debt=remainder=0;lastMicros=host->micros_now();nextSave=lastMicros+5000000;return true;
}
static void returnMenu(){
    gg::speechConsumed();speechStage=speechOffset=0;
    game=capturing=false;gg::capture(false);gg::buttons(0);memset(latestSid,0,26);
    saveBlocked=!saves.flush();cache.close();say(saveBlocked?"SAVE FAILED - FIRE RETRIES; KEEP POWER ON":"RETURNED - FIRE OR RETURN RUNS ROM");replace=true;
}
static void input(const VmInput *i){
    if(!i||!((i->protocol==0x81&&!(i->display&~1))||(i->protocol==0x83&&!(i->display&~3))))return;
    latestButtons=i->buttons;
    if(game)gg::buttons((latestButtons&12)==12?0:latestButtons);
    unsigned next=(tail+1)&31;if(next==head){inputs[(tail-1)&31]=*i;return;}inputs[tail]=*i;tail=next;
}
static void pump(){
    if(!ready&&!pending&&!speechStage&&head!=tail){auto in=inputs[head];head=(head+1)&31;uint8_t pressed=in.buttons&~previous;previous=in.buttons;
        if(game){if((in.buttons&12)==12&&(pressed&12)){returnMenu();head=tail;previous=latestButtons;}else gg::buttons((latestButtons&12)==12?0:latestButtons);}
        else if(count){
            if(pressed&16){selected=selected?selected-1:count-1;menuDirty=true;}
            if(pressed&32){selected=(selected+1)%count;menuDirty=true;}
            if(pressed&64){selected=selected>=17?selected-17:0;menuDirty=true;}
            if(pressed&128){selected=selected+17<count?selected+17:count-1;menuDirty=true;}
            if(pressed&9){char path[384];snprintf(path,sizeof path,"%s/%s",directory,entries[selected].name);loadPath(path,entries[selected].bytes);}
        }
    }
    if(!game)return;
    // A complete boot clip is sent and played with the logo held. In
    // particular, pump must not start DMA while the client is playing it.
    if(gg::speechBytes())return;
    const uint32_t now=host->micros_now(),dt=now-lastMicros;lastMicros=now;
    uint64_t credit=uint64_t(dt)*gg::ClockHz+remainder;debt+=credit/1000000;remainder=credit%1000000;
    // Actual instruction overshoot stays as signed debt; never underflow it or
    // make emulation speed depend on the presentation/ACK cadence.
    unsigned budget=4096;
    while(debt>0&&budget>=128&&!host->should_yield()){
        const auto before=cache.misses;
        unsigned n=unsigned(debt>128?128:debt);gg::run(n);debt-=n;budget=n>=budget?0:budget-n;
        if(gg::speechBytes())break;
        // Yield after a cache miss; retain elapsed time as debt for bounded catch-up.
        if(cache.misses!=before||gg::error())break;
    }
    uint8_t nextSid[26];gg::sid(nextSid);nextSid[0]|=latestSid[0];memcpy(latestSid,nextSid,26);
    if(gg::error()&&!ready&&!pending){const char *why=gg::error();returnMenu();say(why);}
    if(game&&!ready&&!pending&&!videoSubmitted&&int32_t(now-nextSave)>=0){
        if(!saves.flush())returnMenu();
        nextSave=host->micros_now()+5000000;
    }
}
static bool publish(VmPacket *out,uint8_t type,uint8_t flags,unsigned length){inFlight.type=type;inFlight.flags=flags;inFlight.length=length;*out=inFlight;pending=true;return true;}
static bool audio(VmPacket *out,bool end){
    // Direct ROM launch has no picker BASE. Keep early/catch-up audio queued
    // until the first video resume or picker BASE_COMPLETE has been ACKed.
    if(!displayEstablished)return false;
    memcpy(inFlight.payload,latestSid,26);memcpy(sentSid,latestSid,26);frameEnd=end;return publish(out,2,0x20|(end?1:0)|(hires?4:0),26);
}
static bool packet(VmPacket *out){
    if(pending)return false;
    const unsigned speechBytes=game?gg::speechBytes():0;
    if(speechBytes&&!ready&&!videoSubmitted){
        if(!speechStage){speechStage=1;speechOffset=0;inFlight.payload[0]=1;inFlight.payload[1]=0;inFlight.payload[2]=speechBytes;inFlight.payload[3]=speechBytes>>8;return publish(out,6,0,4);}
        inFlight.payload[0]=speechOffset;inFlight.payload[1]=speechOffset>>8;
        if(speechOffset<speechBytes){unsigned n=speechBytes-speechOffset;if(n>226)n=226;memcpy(inFlight.payload+2,gg::speechData()+speechOffset,n);return publish(out,6,1,n+2);}
        return publish(out,6,2,2);
    }
    if(!game&&menuDirty&&!ready)buildMenu();
    if(ready&&game){
        if(!videoSubmitted&&debt>gg::ClockHz/1000&&uint32_t(host->micros_now()-readyMicros)<100000){
            return memcmp(latestSid,sentSid,26)?audio(out,false):false;}
        VmIndexedFrame source{sizeof source,generation,display.pixels,palette,sizeof display.pixels,uint32_t(colorCount)*3,160,144,160,colorCount,0};
        videoSubmitted=true;auto result=host->video_indexed(&source);
        if(result==VmVideoResult::Busy)return false;
        if(result!=VmVideoResult::Transferred){host->fail(0x18,uint32_t(result));return false;}
        videoSubmitted=false;displayEstablished=true;hires=source.resolved_mode!=0;return audio(out,true);
    }
    if(ready){
        unsigned n=0;while(cursor<1000&&n<19){unsigned c=cursor++;if(!replace&&!memcmp(display.picker.cells[c],display.picker.presented[c],10))continue;
            pendingCells[n]=c;auto p=inFlight.payload+n*12;p[0]=c;p[1]=c>>8;memcpy(p+2,display.picker.cells[c],10);n++;}
        if(n){pendingCount=n;unsigned flags=12;if(replace){flags|=1;if(cursor==1000)flags|=2;if(cursor<=19)flags|=16;}return publish(out,1,flags,n*12);}
        return audio(out,true);
    }
    // Picker frame-end heartbeat is required for keyboard/joystick polling.
    if(!game)return audio(out,true);
    return memcmp(latestSid,sentSid,26)?audio(out,false):false;
}
static void ack(){
    if(inFlight.type==6){
        if(inFlight.flags==1)speechOffset+=inFlight.length-2;
        else if(inFlight.flags==2){gg::speechConsumed();speechStage=speechOffset=0;lastMicros=host->micros_now();debt=remainder=0;memset(sentSid,0,26);memset(latestSid,0,26);}
    }
    else if(inFlight.type==1){for(unsigned i=0;i<pendingCount;i++){unsigned c=pendingCells[i];memcpy(display.picker.presented[c],display.picker.cells[c],10);}pendingCount=0;if(inFlight.flags&2)displayEstablished=true;}
    else if(inFlight.type==2){if(!memcmp(latestSid,sentSid,26)){latestSid[0]=0;sentSid[0]=0;}if(frameEnd){ready=false;replace=false;frameEnd=false;cursor=0;}}
    pending=false;
}
static const VmModule module={VM_ABI,sizeof(VmModule),input,pump,packet,ack};
}
extern "C" __attribute__((section(".entry"),used)) const VmModule *vm_entry(const VmHost *h){
    using namespace ggvm;constexpr unsigned required=127;
    constexpr size_t indexedHostBytes=offsetof(VmHost,video_indexed)+sizeof(h->video_indexed);
    if(!h||h->abi!=VM_ABI||h->bytes<indexedHostBytes||(h->services&required)!=required||!h->guest_ram||h->guest_ram_bytes<5*16384||!h->workspace||h->workspace_bytes<8192||!h->open_flags||!h->write||!h->file_op||!h->video_configure||!h->video_indexed||!h->should_yield)return nullptr;
    host=h;saves={};cache={};
    for(unsigned i=0;i<256;i++){palette[i*3]=((i>>5)*255+3)/7;palette[i*3+1]=(((i>>2)&7)*255+3)/7;palette[i*3+2]=(i&3)*85;}
    saveBlocked=false;speechStage=speechOffset=0;head=tail=previous=latestButtons=0;game=ready=pending=displayEstablished=false;replace=menuDirty=true;hires=true;
    VmIndexedVideoSetup setup{sizeof setup,videoWorkspace,sizeof videoWorkspace,0,1,VM_INDEXED_NATIVE_HEIGHT|VM_INDEXED_DOUBLE_WIDTH};
    if(!h->video_configure(&setup))return nullptr;
    if(h->content_path[0]){
        if(strlen(h->content_path)>=sizeof directory||!romName(h->content_path))return nullptr;
        strcpy(directory,h->content_path);auto slash=strrchr(directory,'/');if(!slash)return nullptr;if(slash==directory)slash[1]=0;else *slash=0;
    }else if(snprintf(directory,sizeof directory,"%s/ROMS",h->package_root)>=(int)sizeof directory)return nullptr;
    enumerate();
    if(h->content_path[0]){VmFileInfo info{};auto f=h->open(h->content_path,&info);if(f){h->close(f);if(!info.directory&&loadPath(h->content_path,info.bytes))return &module;}else say("DIRECT ROM NOT FOUND - PICK A ROM");}
    buildMenu();return &module;
}
#if defined(__arm__)
extern "C" void *_sbrk(ptrdiff_t){return reinterpret_cast<void *>(-1);}
extern "C" int _write(int,const void *,int){return -1;}
extern "C" int _read(int,void *,int){return -1;}
extern "C" int _close(int){return -1;}
extern "C" int _fstat(int,void *){return -1;}
extern "C" int _isatty(int){return 0;}
extern "C" int _lseek(int,int,int){return -1;}
extern "C" int _getpid(){return 1;}
extern "C" int _kill(int,int){return -1;}
extern "C" void _exit(int){for(;;){}}
#endif
