# TotalSMS core in GGVM

Imported 2026-09-06 from [ITotalJustice/TotalSMS](https://github.com/ITotalJustice/TotalSMS/tree/05bbb8bbd931d21653cbb6dd7a75a5b198c86c29),
commit `05bbb8bbd931d21653cbb6dd7a75a5b198c86c29`, under MIT.
The scheduler comes from [ITotalJustice/scheduler](https://github.com/ITotalJustice/scheduler/tree/ef78903bb91b681cd0febafb632c3f289a489ede),
tag v1.1.0, commit `ef78903bb91b681cd0febafb632c3f289a489ede`, under MIT.
Both license files are retained here. `upstream-hashes.json` records the exact
original bytes for every imported source file.

This supersedes the MCUME source-import proposal for the Game Gear implementation.
No MCUME Z80, renderer, audio code or external-memory allocator is included.

Local changes:

- Scheduler events/callbacks use eight embedded entries instead of calloc/free.
- `SMS_CartRom` has a bounded page-reader callback; `map_rom_page` resolves ROM
  pages through it. The module owns the SD cache and protects every mapped bank.
- `SMS_load_gg_paged` initializes GG/Sega mapping without dereferencing a whole
  nonresident cartridge. The module validates the header/size and hashes content.
- The VDP renders into a 256-byte scanline and calls the adapter. It evaluates
  sprite collisions/overflow even when capture is disabled; only pixel delivery
  is skipped. The adapter crops x=48..207 and y=24..167 to 160x144.
- The independent `sn76489.h` / `psg.c` backend tracks PSG register writes for
  SID translation. It also records one bounded boot-voice stream: three tone
  periods of one, with channel 3 providing the sample values. Timed attenuation
  codes are inverted and averaged into 4-bit 8 kHz samples, matching the simple
  sample encoding observed in the supplied Sonic 2. This is not a full PSG PCM
  mixer or analogue transfer-curve simulation. Upstream's PCM library is not
  linked. General PCM, stereo playback, noise waveform fidelity and FM remain
  unsupported. The buffer is 8 KiB and resets with the cartridge.
- `machine.cpp` translates native 4-bit GG colors to RGB332, maps held controls,
  emits SID state/retrigger packets and reports unsupported Sega control modes.

The GGVM adapter is derived from the repository's GPL-2.0-or-later GBVM adapter;
see `vm/gg/ggvm.cpp`. The package contains both MIT notices and the GPL text.
Source/build inputs are retained separately from the runtime ZIP. No commercial
cartridge bytes are imported into these source directories or runtime downloads.

The unmodified upstream full-ROM loader and other machine/mapper routines remain
as source reference but unused functions are removed by the module link. GGVM
exposes Sega-mapper GG cartridges only, 32 KiB through 1 MiB, power-of-two sizes.
The database rejects known cartridges outside this profile. No global heap,
constructors, SDL, Arduino, PSRAM or BIOS is linked.

Boot-speech implementation references:
[PSG sample playback](https://www.smspower.org/Development/SamplePlayback) and
[The C64 Digi](https://github.com/Jeff-Birt/C64_DIGI/blob/master/the_c64_digi.txt).
The C64 client uses the documented pulse/TEST DC-source technique for SID volume
playback. No sample bytes from a game are included in the downloadable package.
