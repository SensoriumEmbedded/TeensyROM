// SPDX-License-Identifier: MIT
// SID register backend plus bounded boot-speech capture; no heap or PCM mixer.
#pragma once
#include <stdint.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct Sn76489 {
    uint16_t tone[3];uint8_t volume[4],latch,noise,stereo;uint32_t trigger[4];
    // Packed 4-bit, approximately 8 kHz. Three DC tones / channel-3 volume
    // stream covers Sonic 2's boot voice; other PCM methods remain unsupported.
    uint8_t speech[8192],speech_state;
    uint32_t speech_count,speech_writes,speech_last,speech_cursor,speech_next,speech_start,speech_area,speech_phase;
} Sn76489;
enum {Sn76489LfsrTappedBit_SG=0,Sn76489LfsrFeedBit_SG=0,Sn76489LfsrTappedBit_SMS=0,Sn76489LfsrFeedBit_SMS=0};
Sn76489* psg_init(double clock, unsigned rate);
void psg_reset(Sn76489*,int,int);
void psg_write_io(Sn76489*,uint8_t,int);
void psg_gg_write_io(Sn76489*,uint8_t,int);
static inline void psg_quit(Sn76489*p){(void)p;}
static inline void psg_set_master_volume(Sn76489*p,float v){(void)p;(void)v;}
static inline void psg_set_channel_volume(Sn76489*p,unsigned c,float v){(void)p;(void)c;(void)v;}
void psg_update_timestamp(Sn76489*p,int t);
void psg_end_frame(Sn76489*p,int t);
static inline int psg_samples_avaliable(Sn76489*p){(void)p;return 0;}
static inline int psg_read_samples(Sn76489*p,int16_t*d,size_t n){(void)p;(void)d;(void)n;return 0;}
static inline void psg_clear_samples(Sn76489*p){(void)p;}
#ifdef __cplusplus
}
#endif
