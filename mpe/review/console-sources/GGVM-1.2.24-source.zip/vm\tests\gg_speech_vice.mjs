// Independent CIA/SID playback of the exact generated GGVM player and its
// ROM-derived boot clip. The frontend packet tests cover delivery separately.
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {spawnSync} from 'node:child_process';
const root=path.resolve(import.meta.dirname,'../..'),out=path.resolve(process.argv[2]);
const manifest=JSON.parse(fs.readFileSync(path.join(out,'client.json'))),l=manifest.labels,clip=fs.readFileSync(path.join(out,'boot-speech.pcm4'));
const vice=process.env.MPE_VICE??path.resolve(root,'../AGI-64/tools/VICE-3.10/GTK3VICE-3.10-win64/bin/x64sc.exe');
const hex=n=>n.toString(16).padStart(4,'0'),bytes=b=>b.map(n=>n.toString(16).padStart(2,'0')).join(' ');
const proof=[];
for(const [standard,model] of [['ntsc',0],['ntsc',1],['pal',1]]){
  const dir=path.join(out,`vice-speech-${standard}-${model?'8580':'6581'}`);fs.mkdirSync(dir,{recursive:true});
  const file=n=>path.join(dir,n).replaceAll('\\','/'),write=(n,lines)=>fs.writeFileSync(file(n),lines.join('\n')+'\n');
  write('done.mon',['disable 1','stopwatch','r',`bsave "${file('sid-end.bin')}" 0 $d400 $d418`,'quit']);
  write('start.mon',['bank cpu',`load "${path.join(out,'ggvm.prg').replaceAll('\\','/')}" 0`,
    `bload "${path.join(out,'boot-speech.pcm4').replaceAll('\\','/')}" 0 $8000`,
    '> 0000 2f 35','> d011 3b','> d016 18','> d018 78','> dd00 02','> d01a 00',
    `> 02d6 ${standard==='pal'?'01':'00'}`,`> ${hex(l.gg_speech_total)} ${bytes([clip.length&255,clip.length>>8])}`,
    `> 2a00 78 20 ${bytes([l.gg_speech_play&255,l.gg_speech_play>>8])} ea 4c 04 2a`,
    'break $2a04',`command 1 "playback \\"${file('done.mon')}\\""`,'stopwatch reset','g $2a00']);
  const r=spawnSync(vice,['-default','-'+standard,'-console','-directory',path.dirname(path.dirname(vice)),'-initbreak','reset','+warp',
    '-sound','-sounddev','wav','-soundarg',file('sid.wav'),'-soundrate','44100',
    '-sidengine','1','-sidmodel',String(model),'-monlog','-monlogname',file('monitor.log'),'-moncommands',file('start.mon'),
    '-limitcycles','8000000','-logfile',file('vice.log')],{cwd:dir,encoding:'utf8',windowsHide:true,timeout:20000,maxBuffer:1000000});
  assert.ifError(r.error);assert.equal(r.status,0);assert.deepEqual(fs.readFileSync(file('sid-end.bin')),Buffer.alloc(25));
  const wave=fs.readFileSync(file('sid.wav'));assert.ok(wave.length>44100);assert.equal(wave.toString('ascii',0,4),'RIFF');
  assert.equal(wave.readUInt16LE(34),16);assert.equal(wave.readUInt16LE(22),1);let sum=0,squares=0,n=0;
  for(let i=44;i+1<wave.length;i+=2){const v=wave.readInt16LE(i);sum+=v;squares+=v*v;n++;}
  const rms=Math.sqrt(squares/n-(sum/n)**2);assert.ok(rms>100,'SID output was silent');
  const cycles=Number(fs.readFileSync(file('monitor.log'),'utf8').match(/Stopwatch:\s+(\d+)/)?.[1]);
  const seconds=cycles/(standard==='pal'?985248:1022727),expected=clip.length*2/8000;
  assert.ok(Math.abs(seconds-expected)<0.03,'CIA playback duration differs from the clip');
  proof.push({standard,sid:model?'8580':'6581',cycles,seconds,rms,wavBytes:wave.length});
  console.log(`PASS VICE GG speech ${standard}/${model?'8580':'6581'}: CIA playback completed, SID restored to silence; ${wave.length} WAV bytes`);
}
fs.writeFileSync(path.join(out,'speech-vice-proof.json'),JSON.stringify({physicalAcceptance:false,proof},null,2)+'\n');
