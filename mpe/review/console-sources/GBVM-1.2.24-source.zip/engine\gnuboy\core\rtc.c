// MPE port changes 2026-09-06; derived from MCUME gnuboy, see ../README.md.
// Driven once per emulated second (half-dot units, including CGB double speed).
#include "rtc.h"
struct rtc rtc;

void rtc_latch(byte b)
{
    if(rtc.latch==0 && b==1){
        rtc.regs[0]=rtc.s;rtc.regs[1]=rtc.m;rtc.regs[2]=rtc.h;rtc.regs[3]=rtc.d;
        rtc.regs[4]=(rtc.d>>8)|(rtc.stop<<6)|(rtc.carry<<7);
    }
    rtc.latch=b;
}

void rtc_write(byte b)
{
    switch(rtc.sel){
    case 8: rtc.s=b&63;rtc_units=0;break;
    case 9: rtc.m=b&63;break;
    case 10: rtc.h=b&31;break;
    case 11: rtc.d=(rtc.d&0x100)|b;break;
    case 12: rtc.d=(rtc.d&255)|((b&1)<<8);rtc.stop=(b>>6)&1;rtc.carry=(b>>7)&1;break;
    default: return;
    }
    ++save_revision;
}

void rtc_tick()
{
    if(rtc.stop)return;
    if(++rtc.s>=60){rtc.s=0;
        if(++rtc.m>=60){rtc.m=0;
            if(++rtc.h>=24){rtc.h=0;
                if(++rtc.d>=512){rtc.d=0;rtc.carry=1;}
            }
        }
    }
    ++save_revision;
}
