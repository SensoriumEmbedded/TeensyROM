GBVM incorporates gnuboy by Laguna and Gilgamesh through Jean-Marc Harvengt's
MCUME Teensy port, under GNU GPL v2 or later. See LICENSE-gnuboy.txt.
Complete corresponding source and rebuild tools are supplied separately in
GBVM-1.2.24-source.zip, including engine/gnuboy, vm/gb and scripts/build-gb-core.mjs.
Menu font by Daniel Hepper is public domain; original notices are retained.
Nintendo/Game Boy names identify compatible formats; no endorsement implied.
Use your own lawful game media. No commercial test ROM is included.
