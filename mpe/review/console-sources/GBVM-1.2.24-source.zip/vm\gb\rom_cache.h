// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once
#include "storage.h"
// RAM2-backed 16 KiB banks. Bank zero is pinned; the others use LRU on
// reader calls. The core retains only its most recent returned pointer.
class RomCache {
    const VmHost *host=nullptr;
    uint32_t file=0,bytes=0,stamp=0;
    unsigned slots=0;
    uint8_t lookup[128],banks[32];
    uint32_t used[32];
    bool broken=false;
public:
    uint32_t misses=0,hits=0,stallMicros=0;
    bool initialize(const VmHost *h,uint32_t handle,uint32_t length,unsigned capacity,uint32_t &identity){
        host=h;file=handle;bytes=length;slots=capacity/16384;broken=false;stamp=0;
        misses=hits=stallMicros=0;memset(lookup,255,sizeof lookup);memset(banks,255,sizeof banks);memset(used,0,sizeof used);
        if(slots<2||slots>32||length>2097152||length%16384)return false;
        // Stream the full CRC for existing save identities, retaining just
        // the first cache-sized portion. No full-ROM temporary allocation.
        uint32_t crc=~0u;
        for(uint32_t off=0;off<bytes;off+=4096){
            uint8_t *dest=off<slots*16384?host->guest_ram+off:host->workspace;
            if(host->read(file,off,dest,4096)!=4096)return false;
            crc=gbCrcUpdate(crc,dest,4096);
        }
        for(unsigned i=0;i<slots&&i<bytes/16384;i++){lookup[i]=i;banks[i]=i;used[i]=++stamp;}
        identity=crc^~0u;return true;
    }
    void close(){if(file&&host)host->close(file);file=0;}
    bool opened()const{return file!=0;}
    unsigned capacity()const{return slots;}
    const uint8_t *bank(unsigned index){
        if(broken||index>=bytes/16384)return nullptr;
        unsigned slot=lookup[index];
        if(slot==255){
            if(!file)return nullptr;
            slot=1;
            for(unsigned i=1;i<slots;i++)if(banks[i]==255||uint32_t(stamp-used[i])>uint32_t(stamp-used[slot])){slot=i;if(banks[i]==255)break;}
            if(banks[slot]!=255)lookup[banks[slot]]=255;
            banks[slot]=255;const uint32_t before=host->micros_now();++misses;
            const auto result=host->read(file,index*16384,host->guest_ram+slot*16384,16384);
            stallMicros+=host->micros_now()-before;
            if(result!=16384){broken=true;return nullptr;}
            lookup[index]=slot;banks[slot]=index;
        }else ++hits;
        if(++stamp==0){memset(used,0,sizeof used);stamp=1;}
        used[slot]=stamp;return host->guest_ram+slot*16384;
    }
    static const uint8_t *fetch(void *context,unsigned index){return static_cast<RomCache *>(context)->bank(index);}
};
