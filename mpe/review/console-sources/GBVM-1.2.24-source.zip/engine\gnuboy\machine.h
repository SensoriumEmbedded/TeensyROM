// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once
#include <stdint.h>
#include <stddef.h>
namespace gb {
constexpr uint32_t ClockHz=2097152; // half-dot units; LCD rate unchanged in CGB double speed
struct Video {void *context;void (*line)(void *,unsigned,const uint8_t *,const uint16_t *);void (*frame)(void *);};
struct RomReader {void *context=nullptr;const uint8_t *(*bank)(void *,unsigned)=nullptr;};
constexpr unsigned RtcBytes=16;
// One machine per independently loaded VM. No heap, storage, or hardware calls.
const char *inspect(const uint8_t *rom,size_t bytes);
// With a reader, rom only needs the 0x150-byte header. A returned bank stays
// valid until the next reader call; nullptr stops emulation on a storage error.
// Cartridges with 32 KiB RAM require caller-owned backing of that size.
bool start(const uint8_t *rom,size_t bytes,Video video,RomReader reader={},uint8_t *ram=nullptr,unsigned ramBytes=0);
unsigned run(unsigned units); // actual elapsed units, including final instruction overshoot
void buttons(uint8_t nesWireButtons);
void capture(bool enabled);
const char *error();
bool color();
uint64_t ticks();
void sid(uint8_t packet[26],uint32_t sidClock=1022727);
uint8_t peek(uint16_t address);
void poke(uint16_t address,uint8_t value);
// Battery-backed SRAM only; module owns storage and persistence. The core
// performs no file I/O. Non-battery cartridges return null/zero.
uint8_t *saveData();
unsigned saveBytes();
uint32_t saveRevision();
bool hasRtc();
void clockSave(uint8_t out[RtcBytes]);
bool clockLoad(const uint8_t in[RtcBytes]);
}
