// Actual V1.1.7 indexed service, with only physical DMA and clock stubbed.
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#define FeatVMVideoDMA
#define Fab04_FullDMACapable
enum {DMA_S_DisableReady,DMA_S_Active};
static unsigned DMA_State,nS_DMASetup,nS_MaxAdj,videoConfigurations,videoTransfers;
static unsigned nS_DMADataSetup,nS_DMADataHold;
static constexpr unsigned Def_nS_DMADataSetupNTSC=390,Def_nS_DMADataSetupPAL=390,
    Def_nS_DMADataHoldNTSC=410,Def_nS_DMADataHoldPAL=430;
static uint32_t ARM_DWT_CYCCNT;
static constexpr uint32_t F_CPU_ACTUAL=600000000;
static constexpr unsigned Def_nS_DMASetupNTSC=1,Def_nS_DMASetupPAL=2,Def_nS_MaxAdjNTSC=3,Def_nS_MaxAdjPAL=4;
static uint8_t c64Video[65536];
static bool PerformDMA(bool,uint16_t address,uint8_t *data,uint16_t bytes,bool){
 DMA_State=DMA_S_Active;memcpy(c64Video+address,data,bytes);videoTransfers++;return true;
}
static bool AGIContinueDMA(bool r,uint16_t a,uint8_t *d,uint16_t n,bool f){return PerformDMA(r,a,d,n,f);}
static bool CloseDMA(){DMA_State=DMA_S_DisableReady;return true;}
static void AGIDMAEmergencyRelease(){DMA_State=DMA_S_DisableReady;}
namespace VmRuntime {
static uint8_t videoTiming=0x83;
static uint32_t micros(){return ARM_DWT_CYCCNT/(F_CPU_ACTUAL/1000000u);}
}
#include "Source/Teensy/MinimalBoot/VMIndexedVideo.h"
static bool configureVideo(const VmIndexedVideoSetup *s){
 // No reconfiguration may erase a frozen generation or outstanding host ACK.
 assert(VmRuntime::indexedVideo.phase==0&&!VmRuntime::indexedVideo.hostPacket);
 if(s){assert(s->workspace==VideoArena&&s->workspace_bytes==VM_FULL_VIDEO_WORKSPACE_BYTES);
 assert(s->default_mode==2&&s->capabilities==4);}
 videoConfigurations++;return VmRuntime::configureIndexedVideo(s);
}
static VmVideoResult submitDosVideo(VmIndexedFrame *f){
 // Native executable globals are not ARM RAM1. Mirror just the tiny raster
 // descriptor/palette there; the actual callback still reads the real VRAM.
 auto *extension=reinterpret_cast<VmIndexedDirtyRasterFrame *>(f);auto *r=&extension->raster;
 auto *context=reinterpret_cast<DosRaster *>(VM_DATA_LIMIT-sizeof(DosRaster)-32);
 *context=*static_cast<DosRaster *>(r->context);
 auto arm=*extension;arm.raster.context=context;arm.raster.frame.palette=context->palette;
 auto dirty=reinterpret_cast<uint8_t *>(context)-125;
 memcpy(dirty,extension->source_dirty,125);arm.source_dirty=dirty;
 const auto result=VmRuntime::submitIndexedVideo(&arm.raster.frame);
 r->source_consumed=arm.raster.source_consumed;r->resolved_background=arm.raster.resolved_background;
 r->frame.resolved_mode=arm.raster.frame.resolved_mode;return result;
}
