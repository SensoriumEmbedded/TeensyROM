// SPDX-License-Identifier: GPL-2.0-or-later
// Two checked slots: never overwrite the last verified battery save.
#pragma once
#include "storage.h"
class BatteryStore {
    struct Header {uint32_t magic,rom,bytes,sequence,crc;};
    const VmHost *host=nullptr;
    char directory[320],path[352];
    uint32_t identity=0,serial=0,savedRevision=0;
    int active=-1;
    bool enabled=false;
    uint8_t *scratch(){return host->workspace;}
    unsigned payloadBytes(){return gb::saveBytes()+(gb::hasRtc()?gb::RtcBytes:0);}
    void filename(unsigned slot){snprintf(path,sizeof path,"%s/%08lx.s%u",directory,(unsigned long)identity,slot);}
    bool readSlot(unsigned slot,Header &header,bool &exists,bool restore=false){
        filename(slot);VmFileInfo info{};auto f=host->open(path,&info);
        exists=f!=0&&(info.directory||info.bytes!=0);
        if(!f)return false;
        const unsigned bytes=payloadBytes(),ramBytes=gb::saveBytes();
        bool ok=!info.directory&&info.bytes==sizeof header+bytes&&
            host->read(f,0,&header,sizeof header)==sizeof header&&
            header.magic==0x31534247&&header.rom==identity&&header.bytes==bytes;
        uint32_t crc=~0u;uint8_t clock[gb::RtcBytes]{};
        for(unsigned off=0;ok&&off<bytes;){
            unsigned n=bytes-off;if(n>4096)n=4096;
            ok=host->read(f,sizeof header+off,scratch(),n)==int32_t(n);
            if(!ok)break;
            crc=gbCrcUpdate(crc,scratch(),n);
            if(restore){
                if(off<ramBytes)memcpy(gb::saveData()+off,scratch(),n);
                else memcpy(clock,scratch(),n);
            }
            off+=n;
        }
        ok=ok&&(crc^~0u)==header.crc;
        if(ok&&restore&&gb::hasRtc())ok=gb::clockLoad(clock);
        host->close(f);return ok;
    }
public:
    bool load(const VmHost *h,uint32_t romCrc){
        host=h;identity=romCrc;serial=savedRevision=0;active=-1;enabled=false;
        if(!payloadBytes())return true;
        if(!host->workspace||host->workspace_bytes<4096||!host->open_flags||!host->write||!host->file_op)return false;
        if(snprintf(directory,sizeof directory,"%s/SAVES",host->package_root)>=(int)sizeof directory)return false;
        bool found=false;
        for(unsigned slot=0;slot<2;slot++){
            Header header{};bool exists=false;
            if(readSlot(slot,header,exists)&&(active<0||int32_t(header.sequence-serial)>0)){serial=header.sequence;active=slot;}
            found|=exists;
        }
        if(found&&active<0)return false;
        if(active>=0){Header header{};bool exists=false;if(!readSlot(active,header,exists,true))return false;}
        // Failed load never enables flushing partial data over a valid save.
        enabled=true;savedRevision=gb::saveRevision();return true;
    }
    bool dirty() const {return enabled&&gb::saveRevision()!=savedRevision;}
    bool flush(){
        if(!dirty())return true;
        VmFileInfo info{};auto dir=host->open(directory,&info);
        if(dir){host->close(dir);if(!info.directory)return false;}
        else{VmFsRequest request{VmFsOp::Mkdir,0,1,0,directory,nullptr};if(host->file_op(&request))return false;}
        const unsigned slot=active<0?0:1-active,ramBytes=gb::saveBytes(),bytes=payloadBytes();
        uint8_t clock[gb::RtcBytes];gb::clockSave(clock);
        uint32_t crc=gbCrcUpdate(~0u,gb::saveData(),ramBytes);
        if(gb::hasRtc())crc=gbCrcUpdate(crc,clock,sizeof clock);
        const Header header{0x31534247,identity,bytes,serial+1,crc^~0u};
        filename(slot);auto f=host->open_flags(path,VM_OPEN_WRITE|VM_OPEN_CREATE|VM_OPEN_TRUNCATE,&info);
        if(!f)return false;
        // Materialize the header before appending, respecting FAT no-gap seeks.
        const Header uncommitted{};bool ok=host->write(f,0,&uncommitted,sizeof uncommitted)==sizeof uncommitted;
        for(unsigned off=0;ok&&off<ramBytes;){
            unsigned n=ramBytes-off;if(n>4096)n=4096;
            ok=host->write(f,sizeof header+off,gb::saveData()+off,n)==int32_t(n);off+=n;
        }
        if(ok&&gb::hasRtc())ok=host->write(f,sizeof header+ramBytes,clock,sizeof clock)==sizeof clock;
        if(ok)ok=host->write(f,0,&header,sizeof header)==sizeof header;
        VmFsRequest request{VmFsOp::Flush,f,0,0,nullptr,nullptr};
        if(ok)ok=host->file_op(&request)==0;
        request.operation=VmFsOp::Close;if(host->file_op(&request))ok=false;
        Header checked{};bool exists=false;
        if(!ok||!readSlot(slot,checked,exists)||memcmp(&header,&checked,sizeof header))return false;
        active=slot;serial=header.sequence;savedRevision=gb::saveRevision();return true;
    }
};
