// SPDX-License-Identifier: MIT
// Opt-in ordinary bitmap bank flips, not F5. The visible image stays intact
// during full hires/MC replacements. Both VIC banks contain actor/pointer
// shapes. No CPU reads from the cartridge-covered second bitmap are needed.
export function emitAdventurePresentation(e, stage, state) {
  const targetBank=0x0323,inputTick=0x0324;
  const get=a=>e.abs(0xad,a,'read'),put=a=>e.abs(0x8d,a,'write'),call=n=>e.abs(0x20,n);
  const set=(a,v)=>{e.emit(0xa9,v);put(a);};
  e.label('adventure_prepare_replacement');
  set(state.transitionHidden,1); // Pending replacement; DEN remains enabled.
  get(0xdd00);e.emit(0x29,3,0x49,3);put(targetBank);
  // Bank 2 has VIC character ROM at $9000-$9fff, regardless of CPU $01.
  // Bitmap $6000 <-> $a000, screen $5c00 <-> $8c00 (not $9c00).
  for(const [p,mask] of [['adventure_bitmap_page',0xc0],['adventure_screen_page',0xd0]]){get(p);e.emit(0x49,mask);put(p);}
  set('color_destination_page',0x40); // $4000 staging, clear of $4400 cursor.
  e.emit(0xa2,63);e.label('adventure_copy_cursor');
  e.abs(0xbd,0x4400,'read');e.abs(0x9d,0x8400,'write');e.emit(0xca);e.branch(0x10,'adventure_copy_cursor');
  get(0x5ff8);put(0x8ff8);e.emit(0x60);

  e.label('adventure_prepare_commit');
  get(state.transitionHidden);e.branch(0xf0,'adventure_prepare_done');
  get(stage+5);e.emit(0x29,4);e.branch(0xd0,'adventure_prepare_done');
  // Hires -> MC: load color RAM while the old hires picture ignores it,
  // BEFORE the border wait. MC -> hires copies it after the flip instead.
  call('adventure_copy_colors');e.label('adventure_prepare_done');e.emit(0x60);

  e.label('adventure_publish_bank');
  get(state.transitionHidden);e.branch(0xf0,'adventure_publish_done');
  get(0xdd00);e.emit(0x29,0xfc);e.abs(0x0d,targetBank,'read');put(0xdd00);
  get(targetBank);e.emit(0xc9,1);e.branch(0xf0,'adventure_bank2_screen');
  e.emit(0xa9,0x78);e.branch(0xd0,'adventure_screen_address_ready');
  e.label('adventure_bank2_screen');e.emit(0xa9,0x38);
  e.label('adventure_screen_address_ready');put(0xd018);
  set('color_destination_page',0xd8);
  get(stage+5);e.emit(0x29,4);e.branch(0xf0,'adventure_publish_done');
  call('adventure_copy_colors');e.label('adventure_publish_done');e.emit(0x60);

  e.label('adventure_copy_colors');e.emit(0xa2,0);e.label('adventure_color_byte');
  for(let page=0;page<4;page++){e.abs(0xbd,0x4000+page*256,'read');e.abs(0x9d,0xd800+page*256,'write');}
  e.emit(0xe8);e.branch(0xd0,'adventure_color_byte');e.emit(0x60);

  // Foreground sampling at physical-frame cadence, including packet/border
  // waits. Never read the CIA or POT mux inside the raster interrupt.
  e.label('adventure_service_input');
  e.emit(0x48,0x8a,0x48,0x98,0x48);
  get(state.rasterTicks);e.abs(0xcd,inputTick,'read');e.branch(0xf0,'adventure_input_done');put(inputTick);
  call('sample_skip_input');
  e.label('adventure_input_done');e.emit(0x68,0xa8,0x68,0xaa,0x68,0x60);
}
