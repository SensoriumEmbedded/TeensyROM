// SPDX-License-Identifier: MIT
// Package the exact corresponding-source snapshot already used for relinking.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
export function packageVmSource(source,output,name,version){
  const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
  const files=[];
  function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){
    const file=path.join(dir,e.name);if(e.isDirectory())walk(file);
    else files.push({path:path.relative(source,file).replaceAll('\\','/'),bytes:fs.statSync(file).size,sha256:sha(file)});
  }}
  walk(source);files.sort((a,b)=>a.path.localeCompare(b.path));
  const archive=path.join(output,`${name}-${version}-source.zip`);assert.ok(!fs.existsSync(archive),'Source archive already exists');
  const quote=value=>value.replaceAll("'","''");
  const result=spawnSync('powershell.exe',['-NoProfile','-NonInteractive','-Command',`
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory('${quote(source)}','${quote(archive)}')
$sourceZip=[IO.Compression.ZipFile]::OpenRead('${quote(archive)}');$sourceHash=[Security.Cryptography.SHA256]::Create()
try {$rows=@(foreach($entry in $sourceZip.Entries){if($entry.Name){$stream=$entry.Open();try{$digest=[BitConverter]::ToString($sourceHash.ComputeHash($stream)).Replace('-','').ToLowerInvariant()}finally{$stream.Dispose()};[pscustomobject]@{path=$entry.FullName.Replace([char]92,[char]47);bytes=$entry.Length;sha256=$digest}}});ConvertTo-Json -InputObject $rows -Compress}finally{$sourceZip.Dispose();$sourceHash.Dispose()}
`],{encoding:'utf8',windowsHide:true,maxBuffer:16*1024*1024});
  assert.equal(result.status,0,result.error||result.stderr);
  const readback=JSON.parse(result.stdout).sort((a,b)=>a.path.localeCompare(b.path));assert.deepEqual(readback,files,'Corresponding-source ZIP differs from rebuilt snapshot');
  return {file:path.basename(archive),bytes:fs.statSync(archive).size,sha256:sha(archive),files};
}
