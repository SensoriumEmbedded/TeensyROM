# GBVM gnuboy adapter

Core source: Jean-Marc Harvengt's MCUME, `MCUME_teensy/teensygnuboy`,
commit `27f6b906aca34e06d6647bdca8215e25f8d20aa5`.
Original gnuboy authors: Laguna and Gilgamesh. GPL version 2 or later;
see COPYING and the retained upstream README. License/README reference:
https://github.com/rofl0r/gnuboy . The latter project's newer core was not imported.

MPE modifications, 2026-09-04: standalone callback-only adapter; no Arduino,
TFT, I2S, SD, heap, boot ROM, or copyrighted games included. Replaced the
256 KiB decoded tile cache with 512 bytes of scanline rows; fixed sprite-sort
overread, clipped negative window positions, fixed MBC5 bank zero, made memory
access portable and wrapped, exposed invalid opcodes as a stopping error.
DMG uses four neutral shades. CGB CPU double speed retains LCD/APU time.
The CPU returns actual elapsed half-dot units, including instruction overshoot.
September 5 also fixes the uninitialized window-Y state: WY equality triggers
the window, its line counter pauses while hidden, and skipped capture preserves
that emulated state. No game-specific rendering rules are used.

GBVM links this core as a separate GPL program. Its complete corresponding
source, ABI interface, client sources, build scripts and this license travel
with every packaged binary. `node scripts/build-gb-core.mjs OUTPUT` rebuilds
the module using GNU Arm Embedded 11.3.1 (set MPE_ARM_PREFIX when needed).

September 6 adds a callback for 16 KiB ROM banks, with no retained pointer
across callback calls. The module owns SD caching; resident ROM access stays
direct. Cartridge RAM above 8 KiB uses caller-owned RAM2. Failed bank reads
stop the CPU and suppress memory writes; CGB DMA uses the same bank reader.

Support is intentionally bounded: unbanked type 00, MBC1 types 01/02/03,
MBC3 types 0F/10/11/12/13, MBC5 types 19/1A/1B, ROMs up to 2 MiB, and
0/8/32 KiB cartridge RAM. Large MBC1 ROMs support 0/8 KiB RAM, matching
standard wiring; MBC1M multicarts and other mappers remain unsupported.
The module owns battery persistence through generic host file services.
MBC3's clock supports latching, halt, the 9-bit day counter/carry and saved
subseconds. It advances during emulation only; powered-off/menu time is not
added. The host has no calendar-time service. No save states, link cable, SGB effects,
or PCM fidelity claim.
Sound uses the four gnuboy APU channels and a three-voice SID approximation;
noise steals the wave voice. Original scanline/DMA/timer compatibility limits
remain. This is not an all-games or cycle-accurate emulator claim.

Desktop tests use the user's MARIO1.GB, Pac-Man.gbc, MARIO2.GB, Kirby and
ZELDA.GB locally. They are not
redistributed. Native rendered screenshots, input/picker tests and ARM builds
are evidence of integration, not physical Teensy/C64 gameplay acceptance.
