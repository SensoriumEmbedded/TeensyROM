// SPDX-License-Identifier: MIT
// Native, preprocessed CELL backgrounds + six-hires-sprite actor receiver.
// Reuse the existing packet checks, replay, frame publication and held input.
// No indexed conversion, firmware mode switch, or shared-terminal mutation.
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

export async function loadC64AdventureTerminal(clientRoot, { fullKeyboard = false, largePoses = false, bufferedPresentation = false } = {}) {
  if(bufferedPresentation&&(!fullKeyboard||!largePoses))throw Error('Buffered adventure presentation requires the full keyboard/actor endpoint');
  const file = path.join(clientRoot, 'host/mpe3-title-terminal.mjs');
  let source = fs.readFileSync(file, 'utf8');
  function replaceOnce(before, after) {
    const at = source.indexOf(before);
    if (at < 0 || source.indexOf(before, at + before.length) >= 0) throw Error('Shared terminal changed: review native adventure overlay');
    source = source.slice(0, at) + after + source.slice(at + before.length);
  }
  if (!fullKeyboard) replaceOnce("import { emitMpe4Keyboard, MPE4_INPUT } from './mpe4-keyboard.mjs';",
    `import { MPE4_INPUT } from './mpe4-keyboard.mjs';\nimport { emitNesController } from '${pathToFileURL(path.resolve(clientRoot, '../../nes/tools/nes_terminal.mjs')).href}';`);
  replaceOnce("import { emitMpe4EgoSprites, MPE4_EGO_SPRITES } from './mpe4-ego-sprites.mjs';",
    fullKeyboard
      ? `import { emitC64HiresActor, C64_HIRES_ACTOR as MPE4_EGO_SPRITES } from './c64-hires-actor.mjs';\nconst emitMpe4EgoSprites = (e, stage) => emitC64HiresActor(e, stage, { buffers: [0x4600, 0x4800], largePoses: ${largePoses}, mirrorVicBank: ${bufferedPresentation} });`
      : "import { emitC64HiresActor as emitMpe4EgoSprites, C64_HIRES_ACTOR as MPE4_EGO_SPRITES } from './c64-hires-actor.mjs';");
  if(fullKeyboard&&largePoses){
    replaceOnce("    e.emit(0xc9, MPE3_TITLE_PULL.spriteSidPayloadBytes);\n  }\n  e.branch(0xd0, \"apply_sid_bad\");",
      "    e.emit(0xc9, MPE3_TITLE_PULL.spriteSidPayloadBytes);e.branch(0xf0,'apply_sid_length_ok');e.emit(0xc9,43);e.branch(0xf0,'apply_sid_length_ok');e.emit(0xc9,52);\n  }\n  e.branch(0xd0, \"apply_sid_bad\");");
    replaceOnce("    e.branch(0xd0, 'legacy_frame_publication');",
      "    e.branch(0xf0,'adventure_sprite_frame');e.emit(0xc9,43);e.branch(0xf0,'adventure_sprite_frame');e.emit(0xc9,52);e.branch(0xd0,'legacy_frame_publication');e.label('adventure_sprite_frame');");
    replaceOnce("    e.jumpUnless(0xd0, 'packet_begin_wait');",
      "    e.jumpUnless(0xd0, 'packet_begin_wait');e.emit(0xc9,43);e.jumpUnless(0xd0,'packet_begin_wait');e.emit(0xc9,52);e.jumpUnless(0xd0,'packet_begin_wait');");
  }
  if(bufferedPresentation){
    source=`import { emitAdventurePresentation } from '${pathToFileURL(path.join(clientRoot,'host/c64-adventure-presentation.mjs')).href}';\n`+source;
    replaceOnce('  storeImmediate(e, state.transitionHidden, 1);\n  if (gameplay) e.abs(0x20, "game_ego_hide");\n  storeImmediate(e, 0xd011, 0x2b);\n  e.abs(0x20, "wait_fresh_border");',
      "  e.abs(0x20,'adventure_prepare_replacement');");
    replaceOnce('0xa5, ZP.destinationHigh, 0x18, 0x69, 0x60, 0x85, ZP.destinationHigh);',
      "0xa5, ZP.destinationHigh, 0x18, 0x69);e.label('adventure_bitmap_page');e.emit(0x60, 0x85, ZP.destinationHigh);");
    replaceOnce('0xa5, ZP.cellHigh, 0x69, 0x5c, 0x85, ZP.destinationHigh,',
      "0xa5, ZP.cellHigh, 0x69);e.label('adventure_screen_page');e.emit(0x5c, 0x85, ZP.destinationHigh,");
    replaceOnce('  e.abs(0x20, "apply_sid");\n  e.jumpUnless(0xb0, "error_sid");',
      '  e.abs(0x20, "apply_sid");\n  e.jumpUnless(0xb0, "error_sid");\n  e.abs(0x20,"adventure_prepare_commit");');
    replaceOnce('    e.abs(0x20, "publish_display_policy");\n    e.abs(0x20, \'game_ego_commit\');',
      '    e.abs(0x20, "publish_display_policy");\n    e.abs(0x20, \'game_ego_commit\');\n    e.abs(0x20,"adventure_publish_bank");');
    replaceOnce('  e.label("tick_wait");', '  e.label("tick_wait");\n  e.abs(0x20,"adventure_service_input");');
    replaceOnce('  if (gameplay) emitMpe4Keyboard(e, state.rasterTicks, { enable1351Mouse });',
      '  if (gameplay) emitMpe4Keyboard(e, state.rasterTicks, { enable1351Mouse });\n  emitAdventurePresentation(e,stage,state);');
    let keyboard=fs.readFileSync(path.join(clientRoot,'host/mpe4-keyboard.mjs'),'utf8');
    const pending="  get(s.pending); e.branch(0xf0,'game_input_scan');";
    if(keyboard.split(pending).length!==2)throw Error('Review adventure mouse pending-input adapter');
    keyboard=keyboard.replace(pending,pending+"\n  if(enable1351Mouse){set(0xdc03,0);set(0xdc02,0xc0);set(0xdc00,0x40);call('sample_game_mouse');}");
    keyboard=keyboard.replace(/from '(\.\/[^']+)'/g,(_,relative)=>`from '${pathToFileURL(path.resolve(clientRoot,'host',relative)).href}'`);
    replaceOnce("import { emitMpe4Keyboard, MPE4_INPUT } from './mpe4-keyboard.mjs';",`import { emitMpe4Keyboard, MPE4_INPUT } from 'data:text/javascript;base64,${Buffer.from(keyboard).toString('base64')}';`);
  }
  // The existing 1351 cursor owns $4400. Keep both Roger pose banks clear of
  // it when the full keyboard/mouse endpoint is selected. Other VMs retain
  // their existing held-input protocol and byte-identical actor addresses.
  if (!fullKeyboard) {
  const keyboardCall = source.includes('if (gameplay) emitMpe4Keyboard(e, state.rasterTicks, { enable1351Mouse, mouseRelative });')
    ? 'if (gameplay) emitMpe4Keyboard(e, state.rasterTicks, { enable1351Mouse, mouseRelative });'
    : 'if (gameplay) emitMpe4Keyboard(e, state.rasterTicks, { enable1351Mouse });';
  replaceOnce(keyboardCall, 'if (gameplay) emitNesController(e, state.rasterTicks);');
  replaceOnce('  e.label("packet_idle");', '  e.label("packet_idle");\n  if (gameplay) e.abs(0x20,"nes_service_input");');
  replaceOnce('  e.abs(0xee, MPE3_TITLE_TERMINAL_STATE.rasterTicks, "write");',
    '  e.abs(0xee, MPE3_TITLE_TERMINAL_STATE.rasterTicks, "write");\n' +
    '  if (gameplay) { e.emit(0x8a,0x48,0x98,0x48); e.abs(0x20,"nes_capture_input"); e.emit(0x68,0xa8,0x68,0xaa); }');
  }
  source = source.replace(/from '(\.\/[^']+)'/g, (_, relative) => `from '${pathToFileURL(path.resolve(path.dirname(file), relative)).href}'`);
  return import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
}
