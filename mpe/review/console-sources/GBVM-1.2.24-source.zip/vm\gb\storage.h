// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once
static uint32_t gbCrcUpdate(uint32_t crc,const uint8_t *p,unsigned n){
    while(n--){crc^=*p++;for(unsigned i=0;i<8;i++)crc=(crc>>1)^((crc&1)?0xedb88320u:0);}
    return crc;
}
