// Build a GBVM runtime SD package; retain source/relink proof in build output.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import assert from 'node:assert/strict';import {spawnSync} from 'node:child_process';
import {packageVmSource} from './package-vm-source.mjs';
const root=path.resolve(import.meta.dirname,'..');
const out=path.resolve(process.argv[2]??path.join(root,'build/gb-package'));
assert.ok(!fs.existsSync(path.join(out,'SD')),'Use a fresh output directory');
const pkg=path.join(out,'SD/VMS/GBVM');fs.mkdirSync(pkg,{recursive:true});
const run=(exe,args)=>{const r=spawnSync(exe,args,{cwd:root,encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});assert.equal(r.status,0,r.stderr||r.error);return r.stdout;};
const node=(script,args)=>run(process.execPath,[path.join(root,script),...args]);
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const version='1.2.24';
node('scripts/build-gb-core.mjs',[path.join(out,'core')]);
node('vm/gb/build-client.mjs',['--output-prg',path.join(out,'gbvm.prg'),'--output-boot-bank',path.join(out,'boot.bin'),'--manifest',path.join(out,'client.json')]);
node('vm/tests/gb_client_test.mjs',[out]);
node('nes/tools/build_nesvm_cartridge.mjs',['--id','GBVM','--boot-bank',path.join(out,'boot.bin'),'--output',path.join(pkg,'client.crt'),'--manifest',path.join(out,'cartridge.json')]);
fs.copyFileSync(path.join(out,'core/engine.mvm'),path.join(pkg,'engine.mvm'));
fs.copyFileSync(path.join(pkg,'client.crt'),path.join(out,'SD/GBVM.crt'));
fs.writeFileSync(path.join(pkg,'manifest.vmi'),'VM1\nGBVM\ngb,gbc\nengine.mvm\nclient.crt\nEND\n');
for(const name of ['README.md','NOTICES.md'])fs.copyFileSync(path.join(root,'vms/GBVM',name),path.join(pkg,name));
fs.copyFileSync(path.join(root,'engine/gnuboy/COPYING'),path.join(pkg,'LICENSE-gnuboy.txt'));
fs.writeFileSync(path.join(pkg,'BUILD.json'),JSON.stringify({name:'GBVM',version,minimumFirmwareVersion:'1.1.9',recommendedTravisFirmwareVersion:'1.2.24',compatibleGuiFirmwareVersion:'1.2.23',fix:'Defer startup SID until the first video resume or picker BASE_COMPLETE is acknowledged',physicalHardware:false},null,2)+'\n');
fs.mkdirSync(path.join(pkg,'ROMS'),{recursive:true});fs.writeFileSync(path.join(pkg,'ROMS/README.txt'),'Place your own .gb, .gbc and .gc ROMs here. No games included.\nDirect .gc launch from a firmware browser requires the updated ROM-routing firmware.\n');
const source=path.join(out,'source');fs.mkdirSync(source,{recursive:true});
for(const rel of ['engine/gnuboy','vm/gb','vm/abi','vm/video','vm/client','vm/nes/font8x8.h','vm/tests/gb_client_test.mjs','vm/tests/helpers','nes/tools/nes_terminal.mjs','nes/tools/build_nesvm_cartridge.mjs','scripts/build-gb-core.mjs','scripts/package-gbvm.mjs','firmware-version.json','Source/Teensy/MinimalBoot/Common/VMABI.h','vms/GBVM/README.md','vms/GBVM/NOTICES.md']){
    const dest=path.join(source,rel);fs.mkdirSync(path.dirname(dest),{recursive:true});
    // This F1 client does not use the separate proprietary renderer adapter.
    fs.cpSync(path.join(root,rel),dest,{recursive:true,filter:file=>path.relative(root,file).replaceAll('\\','/')!=='vm/client/host/native-prism-plus-client.mjs'});
}
fs.copyFileSync(path.join(root,'scripts/package-vm-source.mjs'),path.join(source,'scripts/package-vm-source.mjs'));
const prefix=process.env.MPE_ARM_PREFIX??path.join(root,'build/toolchain/Arduino15/packages/teensy/tools/teensy-compile/11.3.1/arm/bin/arm-none-eabi-');
const r=spawnSync(process.execPath,[path.join(source,'scripts/build-gb-core.mjs'),path.join(out,'relink')],{env:{...process.env,MPE_ARM_PREFIX:prefix},encoding:'utf8',windowsHide:true});
assert.equal(r.status,0,r.stderr);assert.equal(sha(fs.readFileSync(path.join(out,'relink/engine.mvm'))),sha(fs.readFileSync(path.join(pkg,'engine.mvm'))));
const correspondingSource=packageVmSource(source,out,'GBVM',version);
const files=[];function walk(dir,rel=''){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name),name=rel+e.name;if(e.isDirectory())walk(p,name+'/');else{assert.ok(!/\.(gb|gbc|gc|nes)$/i.test(name));files.push({path:name,sha256:sha(fs.readFileSync(p))});}}}
walk(path.join(out,'SD'));files.sort((a,b)=>a.path.localeCompare(b.path));
assert.ok(!files.some(f=>f.path.split('/').some(p=>p.toUpperCase()==='SOURCE')));
const zip=path.join(out,'GBVM.zip');assert.ok(!fs.existsSync(zip),'Use a fresh output directory');
const quote=s=>s.replaceAll("'","''");
const rows=JSON.parse(run('powershell.exe',['-NoProfile','-NonInteractive','-Command',`
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory('${quote(path.join(out,'SD'))}','${quote(zip)}')
$gbArchive=[IO.Compression.ZipFile]::OpenRead('${quote(zip)}');$gbHash=[Security.Cryptography.SHA256]::Create()
try { $gbRows=@(foreach($entry in $gbArchive.Entries){if($entry.Name){$stream=$entry.Open();try{$digest=[BitConverter]::ToString($gbHash.ComputeHash($stream)).Replace('-','').ToLowerInvariant()}finally{$stream.Dispose()};[pscustomobject]@{path=$entry.FullName.Replace('\\','/');sha256=$digest}}});ConvertTo-Json -InputObject $gbRows -Compress } finally {$gbArchive.Dispose();$gbHash.Dispose()}
`]));
assert.deepEqual(rows.sort((a,b)=>a.path.localeCompare(b.path)),files);
fs.writeFileSync(path.join(out,'checksums.json'),JSON.stringify({name:'GBVM',version,firmwareVersion:JSON.parse(fs.readFileSync(path.join(root,'firmware-version.json'))).version,minimumFirmwareVersion:'1.1.9',recommendedTravisFirmwareVersion:'1.2.24',release:'gb-direct-startup',maximumRomBytes:2097152,physicalAcceptance:false,correspondingSourceRebuild:true,correspondingSource,abi:2,files,download:{file:'GBVM.zip',bytes:fs.statSync(zip).size,sha256:sha(fs.readFileSync(zip))}},null,2)+'\n');
console.log('Verified GBVM module, client, corresponding-source relink and ZIP: '+zip);
