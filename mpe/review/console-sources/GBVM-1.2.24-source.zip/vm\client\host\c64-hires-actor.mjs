// SPDX-License-Identifier: MIT
// Opt-in actor plane: six hires sprites, three colors, two 21-line rows.
// Packet 7 does not collide with legacy ego/video-control packet 5.
export const C64_HIRES_ACTOR = Object.freeze({
  packetType: 7, shapePayloadBytes: 130, sidPayloadBytes: 37,
  parts: 0x0320, bank: 0x0321, hasPose: 0x0322,
  buffers: Object.freeze([0x4400, 0x4600]), pointerTable: 0x5ff9
});

export function emitC64HiresActor(e, stage, { buffers = C64_HIRES_ACTOR.buffers, largePoses = false, mirrorVicBank = false } = {}) {
  const s = C64_HIRES_ACTOR, descriptor = stage + 8 + 26;
  if (buffers.length !== 2 || buffers[0] % 512 || buffers[1] !== buffers[0] + 512 ||
      buffers[0] < 0x4400 || buffers[1] + 384 > 0x5c00) throw Error('Invalid adventure actor banks');
  const bankPage = buffers[0] >> 8, bankPointer = (buffers[0] - 0x4000) >> 6;
  const get = a => e.abs(0xad, a, 'read'), put = a => e.abs(0x8d, a, 'write');
  const set = (a, v) => { e.emit(0xa9, v); put(a); }, jump = label => e.abs(0x4c, label);
  e.label('game_ego_init');
  for (const address of [s.parts, s.bank, s.hasPose]) set(address, 0);
  e.label('game_ego_hide'); get(0xd015); e.emit(0x29, 0x81); put(0xd015); e.emit(0x60);

  e.label('game_ego_receive');
  get(stage + 6); e.emit(0xc9, 130); e.jumpUnless(0xf0, 'game_ego_bad');
  get(stage + 8); e.emit(0xc9, 1); e.jumpUnless(0xf0, 'game_ego_bad');
  get(stage + 9); e.emit(0xc9, 3); e.jumpUnless(0x90, 'game_ego_bad');
  e.abs(0xcd, s.parts, 'read'); e.jumpUnless(0xf0, 'game_ego_bad');
  // Copy only to the hidden 512-byte bank. Parts 0/1/2 must be in order.
  get(stage + 9); e.emit(0x4a, 0x48);
  get(s.bank); e.emit(0x49, 1, 0x0a, 0x18, 0x69, bankPage, 0x85, 0xf3);
  e.emit(0x68, 0x18, 0x65, 0xf3, 0x85, 0xf3);
  get(stage + 9); e.emit(0x29, 1, 0x4a, 0x6a, 0x85, 0xf2, 0xa0, 0);
  if(mirrorVicBank)e.emit(0xa5,0xf2,0x85,0xf4,0xa5,0xf3,0x49,0xc0,0x85,0xf5);
  e.label('game_ego_copy_byte');
  e.abs(0xb9, stage + 10, 'read'); e.emit(0x91, 0xf2);if(mirrorVicBank)e.emit(0x91,0xf4);e.emit(0xc8, 0xc0, 128);
  e.branch(0xd0, 'game_ego_copy_byte'); e.abs(0xee, s.parts, 'write'); e.emit(0x38, 0x60);

  e.label('game_ego_validate_sid');
  get(stage + 6); e.emit(0xc9, 26); e.branch(0xd0, 'game_ego_extended_sid');
  get(s.parts); e.jumpUnless(0xf0, 'game_ego_bad'); e.emit(0x38, 0x60);
  e.label('game_ego_extended_sid'); e.emit(0xc9, 37);
  if(largePoses){
    e.branch(0xf0,'game_ego_standard_length');e.emit(0xc9,52);e.branch(0xd0,'game_ego_strip_length');
    get(descriptor);e.emit(0xc9,33);e.jumpUnless(0xf0,'game_ego_bad');jump('game_ego_adaptive_format');
    e.label('game_ego_strip_length');e.emit(0xc9,43);e.jumpUnless(0xf0,'game_ego_bad');get(descriptor);e.emit(0xc9,17);e.jumpUnless(0xf0,'game_ego_bad');jump('game_ego_adaptive_format');e.label('game_ego_standard_length');}
  else e.jumpUnless(0xf0, 'game_ego_bad');
  get(stage + 5); e.emit(0x29, 0x20); e.jumpUnless(0xd0, 'game_ego_bad');
  get(descriptor); e.emit(0xc9, 1);
  if (largePoses) {
    e.branch(0xf0, 'game_ego_format_valid'); e.emit(0x29, 0xf3, 0xc9, 2); e.jumpUnless(0xf0, 'game_ego_bad');
    e.label('game_ego_format_valid');
  } else e.jumpUnless(0xf0, 'game_ego_bad');
  if(largePoses){e.label('game_ego_adaptive_format');get(stage+5);e.emit(0x29,0x20);e.jumpUnless(0xd0,'game_ego_bad');}
  get(descriptor + 1); e.emit(0x29, 0x81); e.jumpUnless(0xf0, 'game_ego_bad');
  get(descriptor + 3); e.emit(0xc9, 2); e.jumpUnless(0x90, 'game_ego_bad');
  if(largePoses){
    get(descriptor);e.emit(0xc9,33);e.jumpUnless(0xf0,'game_ego_not_tiled');
    get(descriptor+23);e.emit(0x29,0x81);e.jumpUnless(0xf0,'game_ego_bad');
    for(const at of [descriptor+24,descriptor+25]){get(at);e.emit(0xc9,16);e.jumpUnless(0x90,'game_ego_bad');}
    for(let s=0;s<6;s++){
      get(descriptor+11+s);e.emit(0xc9,64);e.jumpUnless(0x90,'game_ego_bad');e.emit(0x18);e.abs(0x6d,descriptor+4,'read');e.jumpUnless(0x90,'game_ego_bad');
      get(descriptor+17+s);e.emit(0xc9,121);e.jumpUnless(0x90,'game_ego_bad');e.emit(0x18);e.abs(0x6d,descriptor+2,'read');e.emit(0xa9,0);e.abs(0x6d,descriptor+3,'read');e.emit(0xc9,2);e.jumpUnless(0x90,'game_ego_bad');
    }
    jump('game_ego_y_valid');e.label('game_ego_not_tiled');get(descriptor);e.emit(0xc9,17);e.branch(0xd0,'game_ego_fixed_rows');
    for(let s=0;s<6;s++){get(descriptor+11+s);e.emit(0xc9,43);e.jumpUnless(0x90,'game_ego_bad');e.emit(0x18);e.abs(0x6d,descriptor+4,'read');e.jumpUnless(0x90,'game_ego_bad');}
    jump('game_ego_y_valid');e.label('game_ego_fixed_rows');}
  get(descriptor + 1); e.emit(0x29, 0x70); e.branch(0xf0, 'game_ego_y_valid');
  if (largePoses) {
    get(descriptor); e.emit(0x29, 8); e.branch(0xf0, 'game_ego_y_normal');
    get(descriptor + 4); e.emit(0xc9, 214); e.jumpUnless(0x90, 'game_ego_bad'); jump('game_ego_y_valid');
    e.label('game_ego_y_normal');
  }
  get(descriptor + 4); e.emit(0xc9, 235); e.jumpUnless(0x90, 'game_ego_bad');
  e.label('game_ego_y_valid'); e.emit(0xa2, 5);
  e.label('game_ego_validate_color'); e.abs(0xbd, descriptor + 5, 'read'); e.emit(0xc9, 16);
  e.jumpUnless(0x90, 'game_ego_bad'); e.emit(0xca); e.branch(0x10, 'game_ego_validate_color');
  get(s.parts); e.emit(0xc9, 3); e.branch(0xf0, 'game_ego_valid');
  e.emit(0xc9, 0); e.jumpUnless(0xf0, 'game_ego_bad');
  get(descriptor + 1); e.branch(0xf0, 'game_ego_valid');
  get(s.hasPose); e.jumpUnless(0xd0, 'game_ego_bad');
  e.label('game_ego_valid'); e.emit(0x38, 0x60);
  e.label('game_ego_bad'); e.emit(0x18, 0x60);

  e.label('game_ego_commit');
  get(stage + 6); e.emit(0xc9, 37); e.branch(0xf0, 'game_ego_commit_extended');
  if(largePoses){e.emit(0xc9,43);e.branch(0xf0,'game_ego_commit_extended');e.emit(0xc9,52);e.branch(0xf0,'game_ego_commit_extended');}jump('game_ego_hide');
  e.label('game_ego_commit_extended');
  get(s.parts); e.branch(0xf0, 'game_ego_same_shape');
  get(s.bank); e.emit(0x49, 1); put(s.bank); e.emit(0x0a, 0x0a, 0x0a, 0x18, 0x69, bankPointer);
  // The second screen is $8c00, outside the VIC character-ROM shadow.
  for (let i = 0; i < 6; i++) { put(s.pointerTable + i);if(mirrorVicBank)put((s.pointerTable+i)^0xd000); if (i < 5) e.emit(0x18, 0x69, 1); }
  set(s.hasPose, 1); set(s.parts, 0);
  e.label('game_ego_same_shape');
  if (largePoses) { get(descriptor);e.emit(0xc9,33);e.jumpUnless(0xd0,'game_ego_commit_tiles');get(descriptor); e.emit(0x29, 2); e.jumpUnless(0xf0, 'game_ego_commit_mc'); }
  get(descriptor + 2); for (let i = 1; i <= 6; i++) put(0xd000 + i * 2);
  get(0xd010); e.emit(0x29, 0x81); e.abs(0xae, descriptor + 3, 'read'); e.branch(0xf0, 'game_ego_x_msb'); e.emit(0x09, 0x7e);
  e.label('game_ego_x_msb'); put(0xd010);
  if(largePoses){get(descriptor);e.emit(0xc9,17);e.branch(0xd0,'game_ego_fixed_row_commit');
    for(let s=0;s<6;s++){get(descriptor+4);e.emit(0x18);e.abs(0x6d,descriptor+11+s,'read');put(0xd003+s*2);}jump('game_ego_row_commit_done');e.label('game_ego_fixed_row_commit');}
  get(descriptor + 4); for (let i = 1; i <= 3; i++) put(0xd001 + i * 2);
  e.emit(0x18, 0x69, 21); for (let i = 4; i <= 6; i++) put(0xd001 + i * 2);
  if(largePoses)e.label('game_ego_row_commit_done');
  for (let i = 0; i < 6; i++) { get(descriptor + 5 + i); put(0xd028 + i); }
  for (const address of [0xd017, 0xd01b, 0xd01c, 0xd01d]) { get(address); e.emit(0x29, 0x81); put(address); }
  get(0xd015); e.emit(0x29, 0x81); e.abs(0x0d, descriptor + 1, 'read'); put(0xd015); e.emit(0x60);
  if (largePoses) {
    e.label('game_ego_commit_tiles');
    get(0xd010);e.emit(0x29,0x81);put(0xd010);
    for(let s=0;s<6;s++){
      get(descriptor+2);e.emit(0x18);e.abs(0x6d,descriptor+17+s,'read');put(0xd002+s*2);
      e.emit(0xa9,0);e.abs(0x6d,descriptor+3,'read');e.branch(0xf0,`game_ego_tile_x_low_${s}`);
      get(0xd010);e.emit(0x09,2<<s);put(0xd010);e.label(`game_ego_tile_x_low_${s}`);
      get(descriptor+4);e.emit(0x18);e.abs(0x6d,descriptor+11+s,'read');put(0xd003+s*2);
      get(descriptor+5+s);put(0xd028+s);
    }
    get(descriptor+24);put(0xd025);get(descriptor+25);put(0xd026);
    get(0xd01c);e.emit(0x29,0x81);e.abs(0x0d,descriptor+23,'read');put(0xd01c);
    for(const address of [0xd017,0xd01b,0xd01d]){get(address);e.emit(0x29,0x81);put(address);}
    get(0xd015);e.emit(0x29,0x81);e.abs(0x0d,descriptor+1,'read');put(0xd015);e.emit(0x60);
    e.label('game_ego_commit_mc');
    get(0xd010); e.emit(0x29, 0x81); put(0xd010);
    for (let col = 0; col < 3; col++) {
      const coordinate = step => { get(descriptor + 2); e.emit(0x18, 0x69, step * col); put(0xf2); e.emit(0xa9, 0); e.abs(0x6d, descriptor + 3, 'read'); put(0xf3); };
      get(descriptor); e.emit(0x29, 4); e.branch(0xf0, `game_ego_mc_x_normal_${col}`);
      coordinate(48); jump(`game_ego_mc_x_ready_${col}`);
      e.label(`game_ego_mc_x_normal_${col}`); coordinate(24);
      e.label(`game_ego_mc_x_ready_${col}`); get(0xf2); put(0xd002 + col * 2); put(0xd008 + col * 2);
      get(0xf3); e.branch(0xf0, `game_ego_mc_x_low_${col}`); get(0xd010); e.emit(0x09, (1 << (col + 1)) | (1 << (col + 4))); put(0xd010);
      e.label(`game_ego_mc_x_low_${col}`);
    }
    get(descriptor + 4); for (let i = 1; i <= 3; i++) put(0xd001 + i * 2);
    get(descriptor); e.emit(0x29, 8); e.branch(0xf0, 'game_ego_mc_y_normal');
    get(descriptor + 4); e.emit(0x18, 0x69, 42); jump('game_ego_mc_y_ready');
    e.label('game_ego_mc_y_normal'); get(descriptor + 4); e.emit(0x18, 0x69, 21);
    e.label('game_ego_mc_y_ready'); for (let i = 4; i <= 6; i++) put(0xd001 + i * 2);
    get(descriptor + 5); put(0xd025); get(descriptor + 7); put(0xd026);
    get(descriptor + 6); for (let i = 0; i < 6; i++) put(0xd028 + i);
    get(0xd01b); e.emit(0x29, 0x81); put(0xd01b);
    get(0xd01c); e.emit(0x09, 0x7e); put(0xd01c);
    for (const [address, flag] of [[0xd017, 8], [0xd01d, 4]]) {
      get(address); e.emit(0x29, 0x81); put(address); get(descriptor); e.emit(0x29, flag); e.branch(0xf0, `game_ego_mc_expand_${flag}`);
      get(address); e.emit(0x09, 0x7e); put(address); e.label(`game_ego_mc_expand_${flag}`);
    }
    get(0xd015); e.emit(0x29, 0x81); e.abs(0x0d, descriptor + 1, 'read'); put(0xd015); e.emit(0x60);
  }
}
