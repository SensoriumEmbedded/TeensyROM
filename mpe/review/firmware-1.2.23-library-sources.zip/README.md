# Supporting library source for TeensyROM+ MPE 1.2.23

This supplement accompanies `TeensyROM+_0.8.0.8_MPE-1.2.23_full.hex`, SHA256
`2cf0a6b144730bbee92d04bbd812b58163faaafa5acc1ce415d7a70794321156`.
It supplies the corresponding supporting library source for that firmware's
ordinary minimal image and text main image. Their application source is in
the accompanying public TeensyROM checkout. The separate compiled MPE host
and its corresponding library source/relink materials are provided in
`mpe/library/Relink-SDK.zip` and `mpe/library/libMPEPrismHost.a`.

The bundle contains the selected Teensyduino 1.61.0 core and nine supporting
libraries: CRC32, EEPROM, FNET, NativeEthernet, SD, SPI, SdFat, Time, and
USBHost_t36. Original source notices and library metadata are retained.
No private Prism+ implementation, VM engine, GUI image, or game data is
included. See NOTICES.md for the license boundaries.

To reproduce or modify the supporting libraries:

1. Use the public checkout supplied with this review. APPLICATION-INPUTS.json
   records the exact source/build input hashes. Its base commit identifies
   the upstream starting point; that commit alone is not the completed
   reviewed source tree. Keep the matching compiled host package in
   `mpe/library`.
2. Install the recorded Teensyduino 1.61.0 platform and its GNU Arm 11.3.1
   compiler. The original platform URL, archive checksum and tool metadata
   are preserved in `sources/hardware/installed.json`. Use a private copy
   of that Arduino data directory and a private Arduino user directory.
3. Overlay this bundle's `sources/hardware` contents onto the private data
   directory's `packages/teensy/hardware/avr/1.61.0` directory. Overlay
   `sources/user-libraries` contents onto the private user directory's
   `libraries` directory. This restores the matching source and notices;
   compiler binaries come from the pinned tool installation.
4. From the public checkout, run its normal builder with those paths:

```
node mpe/tools/build.mjs --mode mpe --arduino-cli /path/to/arduino-cli --arduino-data /path/to/private/Arduino15 --arduino-user /path/to/private/Arduino --out /path/to/short/build-output
```

On Windows, use a short output directory such as `E:/MPE-build`. The public
builder creates its own staging copy, applies the MPE-only button adapter,
builds each image, and checks image boundaries and firmware-update headroom.
It pins SOURCE_DATE_EPOCH to 1788566400. The matching builder sources are
also retained in `public-build-tools` for provenance; run them in the full
public checkout, where the application and host package are available.

`manifest.json` records the original main/minimal image hashes and their
614 library compilation recipes. Recipe placeholders SOURCES, TOOLCHAIN
and OUTPUT identify this extracted bundle, the GNU Arm 11.3.1 `arm`
directory, and a build output directory. Profiles contain each image's
actual bootdata and linker script. The base core contains the original
yield.cpp used for main/minimal. The builder applies its USB_DISABLED yield
fix only for the separate VM image, whose matching source is in the host
SDK. These deliberate per-image changes are part of the build process.

The public application source plus this supporting source and the compiled
host's relink SDK provide the materials for rebuilding with modified
LGPL-covered libraries. Preserve this source bundle and the host relink SDK
with, or at the same download location as, redistributed combined firmware,
together with their applicable notices. Third-party modification rights
remain effective; MHS Prism+ restrictions apply only to the separately
identified MHS contributions.
