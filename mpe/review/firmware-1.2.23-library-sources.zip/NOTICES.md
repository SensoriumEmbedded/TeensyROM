# Supporting library notices

This bundle preserves the original licenses in each selected source tree.
The following summary does not replace those notices or change their terms.

| Component | License and notice location |
| --- | --- |
| Teensyduino core | Per-file MIT, LGPL-2.1-or-later, BSD and other permissive notices in sources/hardware/cores/teensy4; LICENSE-LGPL-2.1.txt |
| EEPROM | LGPL-2.1-or-later; source header notices and LICENSE-LGPL-2.1.txt |
| SPI | Explicit GPL-2.0 or LGPL-2.1 choice; use under LGPL-2.1 here; original source notices retained |
| Time | LGPL-2.1-or-later source notices; LICENSE-LGPL-2.1.txt |
| NativeEthernet | Per-file notices, including the explicit GPL/LGPL alternative for NativeW5100; the LGPL option applies to that component |
| FNET | Apache-2.0 and per-file notices; source license/notice files and LICENSE-APACHE-2.0.txt |
| SD, SdFat, CRC32 and USBHost_t36 | Original permissive notices in their source trees |
| Vendored PN532 in the public application | BSD-3-Clause; full notice copied to LICENSE-PN532-BSD.txt, including Adafruit Industries and Seeed Technology copyrights |
| FlasherX in the public application | Its public-domain notice is retained in NOTICE-FLASHERX.txt and the public application source |

Both linked minimal/main images were audited from their final compilation
dependency files and linked symbols. No GPL-only compilation dependency or
Bounce implementation remains in this MPE combination. Optional examples
and utilities retain their own source licenses; inclusion in a source tree
does not mean a file was compiled into the firmware. The complete GNU GPL
texts accompany notices that refer to them.

LGPL-covered libraries are used by the firmware. Their source, build
profiles and recipes are supplied here. Their licenses permit modification
and redistribution under their stated terms. The separately supplied host
archive/relink SDK preserves the combined-work modification and debugging
permissions required by the LGPL. New MHS Prism+ contributions retain
their separately identified license and written integration permission;
they do not change the license of any component in this source bundle.
