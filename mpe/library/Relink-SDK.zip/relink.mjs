// SPDX-License-Identifier: MIT
// Rebuild the public glue and link the compiled MPE host into its third image.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
const sdk=import.meta.dirname;
const option=(name,fallback)=>{const i=process.argv.indexOf(name);return i<0?fallback:process.argv[i+1];};
assert(option('--toolchain',process.env.ARM_TOOLCHAIN),'Pass --toolchain PATH to the Teensy GNU Arm 11.3.1 arm directory');
const toolchain=path.resolve(option('--toolchain',process.env.ARM_TOOLCHAIN));
const output=path.resolve(option('--output',path.join(sdk,'output')));
const rebuild=process.argv.includes('--rebuild-libraries');
const verify=process.argv.includes('--verify-original');
const manifest=JSON.parse(fs.readFileSync(path.join(sdk,'manifest.json')));
const config=manifest.profile;
const hash=data=>crypto.createHash('sha256').update(data).digest('hex');
const expand=s=>s.replaceAll('${SDK}',sdk).replaceAll('${TOOLCHAIN}',toolchain).replaceAll('${OUTPUT}',output);
const archive=path.join(sdk,manifest.archive);
assert.equal(hash(fs.readFileSync(archive)),manifest.sha256,'Compiled host archive hash mismatch');
fs.mkdirSync(output,{recursive:true});
function run(name,args){
 const exe=path.join(toolchain,'bin',name.replace(/\.exe$/,'')+(process.platform==='win32'?'.exe':''));
 if(args.join(' ').length>16000){const rsp=path.join(output,'arguments.rsp');fs.writeFileSync(rsp,args.map(a=>'"'+a.replaceAll('\\','/').replaceAll('"','\\"')+'"').join('\n'));args=['@'+rsp];}
 const r=spawnSync(exe,args,{cwd:sdk,encoding:'utf8',windowsHide:true,maxBuffer:16*1024*1024,env:{...process.env,SOURCE_DATE_EPOCH:'1788480000'}});
 assert.equal(r.status,0,exe+'\n'+r.error+'\n'+r.stdout+'\n'+r.stderr);return r.stdout;
}
assert.equal(run('arm-none-eabi-gcc',['-dumpfullversion']).trim(),'11.3.1','Use the recorded compiler version');
const dir=path.join(output,'vm');fs.mkdirSync(dir,{recursive:true});
for(const rel of [...config.objects,'core/core.a']){const dest=path.join(dir,rel);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(path.join(sdk,'objects/vm',rel),dest);}
const recipes=rebuild?config.recipes:config.recipes.filter(r=>r.object==='core/bootdata.c.o');
console.log('Compiling '+recipes.length+' library units and public entry-point glue');
for(const recipe of recipes){fs.mkdirSync(path.dirname(path.join(dir,recipe.object)),{recursive:true});run(recipe.compiler,recipe.arguments.map(expand));}
const core=path.join(dir,'core/core.a');
if(rebuild){fs.unlinkSync(core);run('arm-none-eabi-gcc-ar',['rcs',core,...config.coreMembers.map(member=>path.join(dir,'core',member))]);}
else run('arm-none-eabi-gcc-ar',['r',core,path.join(dir,'core/bootdata.c.o')]);
run(config.stubRecipe.compiler,config.stubRecipe.arguments.map(expand));
const elf=path.join(dir,'MPEBoot.ino.elf'),hex=path.join(dir,'MPEBoot.ino.hex');
run('arm-none-eabi-gcc',['-O2','-Wl,--gc-sections,--relax','-T'+path.join(sdk,'profiles/vm/link.ld'),'-mthumb','-mcpu=cortex-m7','-mfloat-abi=hard','-mfpu=fpv5-d16','-o',elf,path.join(dir,'MPEBoot.ino.cpp.o'),'-Wl,--whole-archive',archive,'-Wl,--no-whole-archive',...config.objects.map(rel=>path.join(dir,rel)),core,'-L'+dir,'-larm_cortexM7lfsp_math','-lm','-lstdc++']);
assert.equal(run('arm-none-eabi-nm',['-u',elf]).trim(),'','Unresolved imports');
const nm=run('arm-none-eabi-nm',['-n','-C',elf]),size=run('arm-none-eabi-size',['-A',elf]);
fs.writeFileSync(path.join(dir,'MPEBoot.nm'),nm);fs.writeFileSync(path.join(dir,'MPEBoot.size'),size);
const symbol=name=>{const m=nm.match(new RegExp('^([0-9a-f]+) \\w '+name+'$','m'));assert(m,'Missing symbol '+name);return parseInt(m[1],16);};
const section=name=>{const m=size.match(new RegExp('^'+name.replaceAll('.','\\.')+'\\s+(\\d+)','m'));assert(m,'Missing section '+name);return Number(m[1]);};
assert(symbol('_etext')<=0x18000);assert.equal(symbol('_itcm_block_count'),6);
assert.equal(symbol('_vm_data_start'),0x20014000);assert.equal(symbol('_vm_data_end'),0x20044000);assert.equal(symbol('_estack'),0x20050000);
assert.equal(symbol('_heap_end')-symbol('_heap_start'),16384);assert(symbol('_heap_end')<=symbol('_vm_data_start'));
assert.equal(section('.bss.dma'),0);assert.equal(section('.bss.extram'),0);
run('arm-none-eabi-objcopy',['-O','ihex','-R','.eeprom',elf,hex]);
const bytes=new Map();let base=0,eof=false;
for(const line of fs.readFileSync(hex,'utf8').trim().split(/\r?\n/)){assert(!eof&&/^:[0-9a-f]+$/i.test(line));const b=Buffer.from(line.slice(1),'hex');assert.equal(b.length,b[0]+5);assert.equal(b.reduce((a,v)=>a+v,0)&255,0);if(b[3]===4)base=b.readUInt16BE(4)*65536;else if(b[3]===0)for(let i=0;i<b[0];i++){const a=base+b.readUInt16BE(1)+i;assert(a>=manifest.flashBase&&a<manifest.flashLimit&&!bytes.has(a));bytes.set(a,b[4+i]);}else if(b[3]===1)eof=true;else assert([3,5].includes(b[3]));}
assert(eof&&bytes.size);
const word=a=>{let v=0;for(let i=0;i<4;i++){assert(bytes.has(a+i));v+=bytes.get(a+i)*2**(8*i);}return v;};
assert.equal(word(manifest.flashBase),0x42464346);assert.equal(word(manifest.flashBase+0x1000),0x432000d1);assert.equal(word(manifest.flashBase+0x1020),manifest.flashBase);
const entry=word(manifest.flashBase+0x1004);assert(entry&1);assert(entry>=manifest.flashBase+0x1000&&entry<manifest.flashBase+0x3001);
const sha256=hash(fs.readFileSync(hex));
if(verify)assert.equal(sha256,manifest.originalHexSha256,'Host image differs from reference');
const report={passed:true,version:manifest.version,archiveSha256:manifest.sha256,rebuildLibraries:rebuild,verifyOriginal:verify,compilerVersion:'11.3.1',hex,sha256,loadedBytes:bytes.size,flashBase:manifest.flashBase,flashLimit:manifest.flashLimit,entry,itcmEnd:symbol('_etext'),heapStart:symbol('_heap_start'),heapBytes:16384,moduleDataStart:symbol('_vm_data_start'),moduleDataBytes:symbol('_vm_data_end')-symbol('_vm_data_start'),stackBytes:symbol('_estack')-symbol('_vm_data_end'),ram2StaticBytes:0,psramStaticBytes:0};
fs.writeFileSync(path.join(output,'verification.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
