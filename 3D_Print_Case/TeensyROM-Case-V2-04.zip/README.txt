TeensyROM case V2.0

In this archive, there is only one case top for the TeensyROM, and it
is this one:
* TeensyROM-V2-Case-Top.stl

There are two case bottoms to choose from.  The one labeled No-Hole-PCB
will work for versions of TeensyROM with and without a hole in the PCB.
Older versions of TeensyROM came with a PCB without a screw hole.  This
(No-Hole-PCB) is the case bottom for those versions.  If your PCB has a
hole for a screw, then TeensyROM-V2-Case-Bottom.stl is for you.
* TeensyROM-V2-Case-Bottom.stl
* TeensyROM-V2-Case-Bottom-No-Hole-PCB.stl

There are two button lengths to choose from.  These buttons take mere
minutes to print so no harm in printing both to see which one fits you
better.  Most people probably want the Long button.  Use the Short
button if the complete push-button (base and shaft) on your TeensyROM
is about 6 mm or aprrox. 1/4 inch tall.
* TeensyROM-V2-Button-Long.stl
* TeensyROM-V2-Button-Short.stl